This  shows the configuration for network devices using **`systemd-networkd`** on a Linux system. It involves **network bonding (Link Aggregation)** and **VLANs (Virtual Local Area Networks)**.

mtint@camillo:/etc/systemd/network$ ls -la

-rw-r--r-- 1 root root   81 Nov 20  2023 01-bond1.netdev
-rw-r--r-- 1 root root   68 Nov 16  2023 02-118.netdev
-rw-r--r-- 1 root root   66 Nov 16  2023 03-119.netdev
-rw-r--r-- 1 root root  151 Nov 16  2023 10-bond1.network
-rw-r--r-- 1 root root   49 Nov 16  2023 20-enp152s0f0np0.network
-rw-r--r-- 1 root root   49 Nov 16  2023 21-enp152s0f1np1.network
-rw-r--r-- 1 root root  176 Nov 16  2023 25-globe.network
-rw-r--r-- 1 root root   89 Nov 16  2023 26-ceph.network
-rw-r--r-- 1 root root  123 Nov 20  2023 30-enp75s0f0.network

::::::::::::::
01-bond1.netdev
::::::::::::::
[NetDev]
Name=bond1
Description=Bond of 25Gb NICs
Kind=bond

[Bond]
Mode=802.3ad
::::::::::::::
02-118.netdev
::::::::::::::
[NetDev]
Name=globe
Description=Globe VLAN
Kind=vlan

[VLAN]
Id=118
::::::::::::::
03-119.netdev
::::::::::::::
[NetDev]
Name=ceph
Description=Ceph VLAN
Kind=vlan

[VLAN]
Id=119
::::::::::::::
10-bond1.network
::::::::::::::
[Match]
Name=bond1

[Network]
Description=VLANs on bond1
VLAN=globe
VLAN=ceph
LinkLocalAddressing=no
LLDP=no
EmitLLDP=no
IPv6AcceptRA=no
IPv6SendRA=no
::::::::::::::
20-enp152s0f0np0.network
::::::::::::::
[Match]
Name=enp152s0f0np0

[Network]
Bond=bond1
::::::::::::::
21-enp152s0f1np1.network
::::::::::::::
[Match]
Name=enp152s0f1np1

[Network]
Bond=bond1
::::::::::::::
25-globe.network
::::::::::::::
[Match]
Name=globe
Type=vlan

[Network]
Description=Globe VLAN
Address=172.30.118.70/24
DNS=172.30.110.5 172.30.115.2
Domains=globe.AMAZON.co.uk

[Route]
Gateway=172.30.118.254


::::::::::::::
26-ceph.network
::::::::::::::
[Match]
Name=ceph
Type=vlan

[Network]
Description=Ceph Data VLAN
Address=192.168.1.1/24
::::::::::::::
30-enp75s0f0.network
::::::::::::::
[Match]
Name=enp75s0f0

[Network]
Address=10.10.100.70/24
DNS=10.10.100.125 10.10.100.151
Domains=admin.globe.AMAZON.co.uk

Here's a diagram illustrating the network configuration across three Proxmox/Ceph integrated servers, utilizing the bonding and VLANs you've defined.

In this diagram, each server has two bonded 25Gb interfaces (for `bond1`) and one separate 10Gb interface (`enp75s0f0`). The `globe` VLAN (ID 118) provides external/management access, and the `ceph` VLAN (ID 119) is dedicated for Ceph cluster communication.

![[Gemini_Generated_Image_4a82lf4a82lf4a82.png]]

Here is a detailed explanation and documentation of the files and the resulting network setup.

---

## 💻 `systemd-networkd` Configuration Explanation

The files shown are configuration units for `systemd-networkd`, a system service that manages network configurations on Linux. These files are located in `/etc/systemd/network/` and use the INI file format.

### 1. File Listing (`ls -la`)

The first part of the output shows the files present in the configuration directory:

|**Filename**|**Type**|**Description**|
|---|---|---|
|`01-bond1.netdev`|**NetDev**|Defines the bonded interface (`bond1`).|
|`02-118.netdev`|**NetDev**|Defines the VLAN interface for ID **118** (`globe`).|
|`03-119.netdev`|**NetDev**|Defines the VLAN interface for ID **119** (`ceph`).|
|`10-bond1.network`|**Network**|Assigns the VLANs (`globe` and `ceph`) to the **`bond1`** interface.|
|`20-enp152s0f0np0.network`|**Network**|Assigns the physical NIC **`enp152s0f0np0`** as a member of **`bond1`**.|
|`21-enp152s0f1np1.network`|**Network**|Assigns the physical NIC **`enp152s0f1np1`** as a member of **`bond1`**.|
|`25-globe.network`|**Network**|Configures the **`globe`** VLAN interface with IP address, DNS, and gateway.|
|`26-ceph.network`|**Network**|Configures the **`ceph`** VLAN interface with an IP address.|
|`30-enp75s0f0.network`|**Network**|Configures a **separate** physical NIC **`enp75s0f0`** with its own IP and DNS.|

---

## 🌐 Detailed Network Setup Documentation

The configuration establishes three main network connections:

1. **Bonded Interface (High-Speed/Redundant Link)**
    
2. **VLAN Interfaces (`globe` and `ceph`)**
    
3. **Standalone Interface (`enp75s0f0`)**
    

### A. Network Bond (`bond1`)

A **Link Aggregation Group (LAG)** or **Bond** named **`bond1`** is created for redundancy and/or increased throughput.

- **`01-bond1.netdev` (The Bond Definition):**
    
    - **Name:** `bond1`
        
    - **Kind:** `bond`
        
    - **Mode:** `802.3ad` (This is **LACP**—Link Aggregation Control Protocol—requiring switch configuration).
        
- **Member Interfaces:**
    
    - **`20-enp152s0f0np0.network`** and **`21-enp152s0f1np1.network`** designate the physical NICs `enp152s0f0np0` and `enp152s0f1np1` to be part of the `bond1` group.
        
- **Function:** The two physical NICs act as a single logical interface (`bond1`).
    

### B. VLAN Interfaces (`globe` and `ceph`)

Two **VLAN** interfaces are created on top of the `bond1` interface. This allows the single `bond1` link to carry traffic for multiple isolated logical networks.

- **`02-118.netdev` (The `globe` VLAN Definition):**
    
    - **Name:** `globe`
        
    - **Kind:** `vlan`
        
    - **VLAN ID:** `118`
        
- **`03-119.netdev` (The `ceph` VLAN Definition):**
    
    - **Name:** `ceph`
        
    - **Kind:** `vlan`
        
    - **VLAN ID:** `119`
        
- **`10-bond1.network` (VLAN Assignment):**
    
    - This file attaches both the `globe` and `ceph` VLANs to the parent interface, **`bond1`**.
        

#### 1. `globe` VLAN Configuration

This network is configured with full routing and DNS for accessing an external network (likely "globe.AMAZON.co.uk").

|**Setting**|**Value**|**Description**|
|---|---|---|
|**Interface**|`globe` (Type `vlan`)|Matches the VLAN interface name.|
|**IP Address**|`172.30.118.70/24`|Static IPv4 address.|
|**Gateway**|`172.30.118.254`|Default gateway for the `172.30.118.0/24` network.|
|**DNS**|`172.30.110.5, 172.30.115.2`|Primary and secondary DNS servers.|
|**Domains**|`globe.AMAZON.co.uk`|DNS search domain.|

#### 2. `ceph` VLAN Configuration

This network appears to be a local or private network, likely for Ceph storage cluster traffic, as it only has a local address assigned.

|**Setting**|**Value**|**Description**|
|---|---|---|
|**Interface**|`ceph` (Type `vlan`)|Matches the VLAN interface name.|
|**IP Address**|`192.168.1.1/24`|Static IPv4 address.|
|**Description**|`Ceph Data VLAN`|Indicates the purpose of this isolated network.|

### C. Standalone Interface (`enp75s0f0`)

The final network file configures a separate physical interface, independent of the `bond1` and VLAN setup.

- **`30-enp75s0f0.network` (Configuration):**
    
    - **Interface** | `enp75s0f0` | Matches the physical NIC name.
        
    - **IP Address** | `10.10.100.70/24` | Static IPv4 address.
        
    - **DNS** | `10.10.100.125, 10.10.100.151` | Separate DNS servers for this network.
        
    - **Domains** | `admin.globe.AMAZON.co.uk` | Separate DNS search domain.
        

### Summary of Logical Interfaces

After applying this configuration, the system should have the following primary logical network interfaces:

1. **`enp152s0f0np0`**: A member (slave) of `bond1` (no direct IP).
    
2. **`enp152s0f1np1`**: A member (slave) of `bond1` (no direct IP).
    
3. **`bond1`**: The master bond interface (no direct IP, carries VLAN tags).
    
4. **`globe`**: VLAN 118 on `bond1` with IP `172.30.118.70`.
    
5. **`ceph`**: VLAN 119 on `bond1` with IP `192.168.1.1`.
    
6. **`enp75s0f0`**: Standalone interface with IP `10.10.100.70`.
    

This setup uses the `bond1` interface for high-availability access to both the `globe` and `ceph` networks via VLAN tagging, while reserving `enp75s0f0` for a separate administrative or dedicated connection.

The diagram and configuration represent a **highly available, high-performance, and segregated network design** commonly used in **Hyper-Converged Infrastructure (HCI)** setups like a **Proxmox Virtual Environment (PVE) cluster with integrated Ceph storage**.

This setup is designed to meet the best practices for Ceph and Proxmox networking by separating different types of traffic.

---

## 🚀 Core Networking Components and Purpose

The entire configuration revolves around establishing **three functionally distinct networks** on the hypervisor:

1. **High-Speed Bonded Link (`bond1`)** for Storage and VM/Management traffic.
    
2. **Dedicated Management Link (`enp75s0f0`)** for a separate administrative path.
    

### 1. High-Speed Bonded Link (`bond1`)

This is the primary connection for all cluster-critical and storage traffic, combining two high-speed NICs for redundancy and bandwidth.

- **Interfaces:** `enp152s0f0np0` and `enp152s0f1np1` (likely 25GbE NICs).
    
- **Bond Type:** **`Mode=802.3ad` (LACP)**. This is an active link aggregation protocol that requires switch support. It provides high availability (if one physical link fails, the bond stays up) and increases aggregate throughput.
    
- **VLAN Trunks:** The `bond1` interface is configured in `10-bond1.network` to carry traffic for two Virtual Local Area Networks (VLANs): `globe` (VLAN 118) and `ceph` (VLAN 119). The switch port this bond connects to must be configured as a **trunk port** allowing these two VLANs.
    

### 2. VLAN Segmentation (The Logical Networks)

VLANs are essential here for **network segregation**, which is a Ceph best practice to ensure high-bandwidth storage traffic doesn't interfere with general management or VM traffic.

|**VLAN Interface**|**VLAN ID**|**IP Network**|**Traffic Type/Purpose**|
|---|---|---|---|
|**`globe`**|**118**|`172.30.118.0/24`|**Proxmox/VM Public & Management Network.** This is used for Proxmox GUI access, VM/LXC network access, VM migration traffic, and is the Ceph **Public Network** (where clients, like VMs, connect to Ceph). It has an assigned DNS and Gateway (`25-globe.network`).|
|**`ceph`**|**119**|`192.168.1.0/24`|**Ceph Cluster Network** (Private). This network is dedicated to the **Ceph back-end traffic**, specifically for inter-OSD data replication, rebalancing, and recovery. It is critical for performance and recovery speed. It has a static IP but **no gateway** (`26-ceph.network`), as it's a private, cluster-local network.|

### 3. Dedicated Admin/Fallback Link

The final interface is a completely separate network path.

- **Interface:** `enp75s0f0` (likely a 1GbE or 10GbE NIC).
    
- **Network:** `10.10.100.0/24`
    
- **Purpose:** This serves as a **separate administrative/management network**. In a production environment, this is often used for a segregated **Out-of-Band (OOB) or Corosync** cluster link. It is wise to have a dedicated link separate from the high-load bonded network to ensure you always have access to the hypervisor, even if the primary data network is congested or misconfigured.
    

---

## 💾 Proxmox/Ceph Integrated Use Case

For the three-node Proxmox/Ceph cluster:

- **High-Bandwidth Storage (Ceph):** The `bond1` interface, providing 2xNIC bandwidth/redundancy, handles the heavy lifting for both Ceph's **Public** (client-to-storage) and **Cluster** (storage-to-storage replication) networks, segregated via VLANs 118 and 119.
    
- **Fault Tolerance:** The **802.3ad bond** ensures that a single cable or NIC failure does not bring down the entire node's primary network connectivity, protecting both VM and Ceph traffic.
    
- **Management:** Proxmox management and Corosync (cluster communication) traffic would primarily use the **`globe` (VLAN 118)** network, with the **`enp75s0f0` (10.10.100.x)** network as a redundant, dedicated administrative access and cluster ring.
    

The video below explains why network separation is crucial when implementing Ceph storage within a Proxmox cluster.

https://www.youtube.com/watch?v=-qk_P9SKYK4

You might find this video useful for understanding the broader context of Proxmox and Ceph networking: Proxmox 8 Cluster with Ceph Storage configuration.