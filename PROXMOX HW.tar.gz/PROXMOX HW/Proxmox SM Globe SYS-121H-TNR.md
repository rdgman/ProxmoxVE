Here's a clear summary of the information from the image:

**System Information**

- **Manufacturer:** Supermicro
    
- **Model:** SYS-121H-TNR
    
- **Serial Number:** E491001X5300200
    
- **Power State:** On
    
- **BMC IP:** 192.168.1.14
    
- **BMC MAC:** 7C:C2:55:8B:AD:75
    
- **BMC Firmware:** 01.03.50
    
- **BIOS Firmware:** 2.5
    

**Chassis**

- **Type:** Other
    
- **Part Number:** CSE-HS119-R1K24P2
    
- **Serial Number:** CH119KN37BA0398
    

**CPU**

- **2 × Intel® Xeon® Silver 4410Y**
    
    - 12 cores / 24 threads each
        
    - 2000 MHz base speed
        
    - 150W TDP
        
    - Manufacturer: Intel
        

**Memory (RAM)**

- **8 × 16GB DDR5 ECC** (SK Hynix, 4000 MT/s)
    
    - Total: **128GB**
        
    - Slots populated: P1-DIMMA1, P1-DIMMC1, P1-DIMME1, P1-DIMMG1, P2-DIMMA1, P2-DIMMC1, P2-DIMME1, P2-DIMMG1
        

**PSU**

- PSU information present but no specific data (temps, fans, serials not filled).
    

Would you like me to turn this into a **hardware inventory report** (e.g., in Markdown, CSV, or PDF format) for documentation?


![[Pasted image 20250917130403.png]]
Here’s a summary of the BIOS storage configuration screen you shared:

**Aptio Setup – Advanced (Drive Configuration)**

- **Select Media Type:** Both
    
- **Select Interface Type:** All
    
- **Logical Sector Size:** Both
    

**Unconfigured Drives Detected:**

1. **Drive 00:01:00** – SSD, SATA, 446.625 GB, Unconfigured Good, (Opal), 512B – **Disabled**
    
2. **Drive 00:01:01** – SSD, SATA, 446.625 GB, Unconfigured Good, (Opal), 512B – **Disabled**
    
3. **Drive 00:01:02** – SSD, SATA, 1.746 TB, Unconfigured Good, (Opal), 512B – **Disabled**
    
4. **Drive 00:01:03** – SSD, SATA, 1.746 TB, Unconfigured Good, (Opal), 512B – **Disabled**
    

Options available:

- Check All
    
- Uncheck All
    
- Apply Changes
    

This screen is essentially showing that four SSD drives (two 446 GB and two 1.7 TB) are present but currently **disabled/unconfigured** in the BIOS storage controller settings.

---------

### Key Applications

- Virtualization
- Software-defined Storage
- AI Inference and Machine Learning
- Cloud Computing
- Enterprise Server

### Key Features

1. Dual Socket E (LGA-4677) 5th/4th Gen Intel® Xeon® Scalable processors
2. 32 DIMM slots supporting up to 8TB of memory; RDIMMs up to DDR5-5600
3. 3 PCIe 5.0 x16 slots with support for GPU/Accelerator cards
4. Flexible networking options with 1 AIOM networking slot (OCP NIC 3.0 compatible)
5. 8x 2.5" hot-swap NVMe/SATA/SAS drive bays; Optional 4x 2.5" hot-swap NVMe/SAS/SATA drive bays; 2x internal M.2 NVMe/SATA drive slots; Optional RAID support via storage add-on card
6. 8 heavy duty hot-swap fans with optimal fan speed control

Compare
