Ready-to-run scripts for a 3-node Proxmox + Ceph build using:

- LACP bond across the two 25 Gb ports
    
- VLAN 141 = public/management (213.123.2.0/24)
    
- VLAN 1922 = Ceph cluster/backend (192.168.2.0/24)
    
- Per node: **3 data HDDs** (/dev/sdb /dev/sdc /dev/sdd) + **1 metadata NVMe** (/dev/nvme1n1) for BlueStore DB/WAL
    
- Proxmox OS assumed on separate NVMe(s)
    

> ⚠️ The OSD script **DESTROYS DATA** on the listed disks.

---

# Node IP plan (edit if needed)

- **node1**: public `213.123.2.101/24` (gw `213.123.2.1`), cluster `192.168.2.11/24`
    
- **node2**: public `213.123.2.102/24` (gw `213.123.2.1`), cluster `192.168.2.12/24`
    
- **node3**: public `213.123.2.103/24` (gw `213.123.2.1`), cluster `192.168.2.13/24`
    

NIC names below assume `ens1f0` and `ens1f1`. If yours differ, change the two IFACE lines in each network script.

---

## 1) Network (bond + VLANs)

### node1 – `network_setup_node1.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail

IFACE1="ens1f0"
IFACE2="ens1f1"
MTU="9000"
BOND="bond0"
BOND_MODE="802.3ad"
BOND_MIIMON="100"
BOND_XMIT_HASH="layer3+4"

VLAN_PUBLIC_ID="141"
VLAN_CLUSTER_ID="1922"

PUBLIC_CIDR="213.123.2.101/24"
PUBLIC_GW="213.123.2.1"
CLUSTER_CIDR="192.168.2.11/24"

CREATE_PUBLIC_BRIDGE="yes"
VM_BR="vmbr141"

require_pkg(){ dpkg -s "$1" >/dev/null 2>&1 || { apt-get update -y; apt-get install -y "$1"; }; }

require_pkg ifupdown2
cp -a /etc/network/interfaces /etc/network/interfaces.bak.$(date +%F-%H%M%S)

cat >/etc/network/interfaces <<EOF
source /etc/network/interfaces.d/*

auto lo
iface lo inet loopback

allow-hotplug ${IFACE1}
iface ${IFACE1} inet manual
    mtu ${MTU}

allow-hotplug ${IFACE2}
iface ${IFACE2} inet manual
    mtu ${MTU}

auto ${BOND}
iface ${BOND} inet manual
    bond-slaves ${IFACE1} ${IFACE2}
    bond-miimon ${BOND_MIIMON}
    bond-mode ${BOND_MODE}
    bond-xmit-hash-policy ${BOND_XMIT_HASH}
    mtu ${MTU}
    lacp-rate fast

auto ${BOND}.${VLAN_PUBLIC_ID}
iface ${BOND}.${VLAN_PUBLIC_ID} inet static
    address ${PUBLIC_CIDR}
    gateway ${PUBLIC_GW}
    vlan-raw-device ${BOND}
    mtu ${MTU}

auto ${BOND}.${VLAN_CLUSTER_ID}
iface ${BOND}.${VLAN_CLUSTER_ID} inet static
    address ${CLUSTER_CIDR}
    vlan-raw-device ${BOND}
    mtu ${MTU}
EOF

if [[ "${CREATE_PUBLIC_BRIDGE}" == "yes" ]]; then
cat >>/etc/network/interfaces <<EOF

auto ${VM_BR}
iface ${VM_BR} inet manual
    bridge-ports ${BOND}
    bridge-stp off
    bridge-fd 0
    bridge-vlan-aware yes
    bridge-vids ${VLAN_PUBLIC_ID}
    mtu ${MTU}
EOF
fi

ifreload -a
echo "[OK] network applied"
```

### node2 – `network_setup_node2.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail
IFACE1="ens1f0"; IFACE2="ens1f1"; MTU="9000"; BOND="bond0"; BOND_MODE="802.3ad"; BOND_MIIMON="100"; BOND_XMIT_HASH="layer3+4"
VLAN_PUBLIC_ID="141"; VLAN_CLUSTER_ID="1922"
PUBLIC_CIDR="213.123.2.102/24"; PUBLIC_GW="213.123.2.1"; CLUSTER_CIDR="192.168.2.12/24"
CREATE_PUBLIC_BRIDGE="yes"; VM_BR="vmbr141"
require_pkg(){ dpkg -s "$1" >/dev/null 2>&1 || { apt-get update -y; apt-get install -y "$1"; }; }
require_pkg ifupdown2
cp -a /etc/network/interfaces /etc/network/interfaces.bak.$(date +%F-%H%M%S)
cat >/etc/network/interfaces <<EOF
source /etc/network/interfaces.d/*

auto lo
iface lo inet loopback

allow-hotplug ${IFACE1}
iface ${IFACE1} inet manual
    mtu ${MTU}
allow-hotplug ${IFACE2}
iface ${IFACE2} inet manual
    mtu ${MTU}

auto ${BOND}
iface ${BOND} inet manual
    bond-slaves ${IFACE1} ${IFACE2}
    bond-miimon ${BOND_MIIMON}
    bond-mode ${BOND_MODE}
    bond-xmit-hash-policy ${BOND_XMIT_HASH}
    mtu ${MTU}
    lacp-rate fast

auto ${BOND}.${VLAN_PUBLIC_ID}
iface ${BOND}.${VLAN_PUBLIC_ID} inet static
    address ${PUBLIC_CIDR}
    gateway ${PUBLIC_GW}
    vlan-raw-device ${BOND}
    mtu ${MTU}

auto ${BOND}.${VLAN_CLUSTER_ID}
iface ${BOND}.${VLAN_CLUSTER_ID} inet static
    address ${CLUSTER_CIDR}
    vlan-raw-device ${BOND}
    mtu ${MTU}
EOF

cat >>/etc/network/interfaces <<EOF

auto ${VM_BR}
iface ${VM_BR} inet manual
    bridge-ports ${BOND}
    bridge-stp off
    bridge-fd 0
    bridge-vlan-aware yes
    bridge-vids ${VLAN_PUBLIC_ID}
    mtu ${MTU}
EOF

ifreload -a
echo "[OK] network applied"
```

### node3 – `network_setup_node3.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail
IFACE1="ens1f0"; IFACE2="ens1f1"; MTU="9000"; BOND="bond0"; BOND_MODE="802.3ad"; BOND_MIIMON="100"; BOND_XMIT_HASH="layer3+4"
VLAN_PUBLIC_ID="141"; VLAN_CLUSTER_ID="1922"
PUBLIC_CIDR="213.123.2.103/24"; PUBLIC_GW="213.123.2.1"; CLUSTER_CIDR="192.168.2.13/24"
CREATE_PUBLIC_BRIDGE="yes"; VM_BR="vmbr141"
require_pkg(){ dpkg -s "$1" >/dev/null 2>&1 || { apt-get update -y; apt-get install -y "$1"; }; }
require_pkg ifupdown2
cp -a /etc/network/interfaces /etc/network/interfaces.bak.$(date +%F-%H%M%S)
cat >/etc/network/interfaces <<EOF
source /etc/network/interfaces.d/*

auto lo
iface lo inet loopback

allow-hotplug ${IFACE1}
iface ${IFACE1} inet manual
    mtu ${MTU}
allow-hotplug ${IFACE2}
iface ${IFACE2} inet manual
    mtu ${MTU}

auto ${BOND}
iface ${BOND} inet manual
    bond-slaves ${IFACE1} ${IFACE2}
    bond-miimon ${BOND_MIIMON}
    bond-mode ${BOND_MODE}
    bond-xmit-hash-policy ${BOND_XMIT_HASH}
    mtu ${MTU}
    lacp-rate fast

auto ${BOND}.${VLAN_PUBLIC_ID}
iface ${BOND}.${VLAN_PUBLIC_ID} inet static
    address ${PUBLIC_CIDR}
    gateway ${PUBLIC_GW}
    vlan-raw-device ${BOND}
    mtu ${MTU}

auto ${BOND}.${VLAN_CLUSTER_ID}
iface ${BOND}.${VLAN_CLUSTER_ID} inet static
    address ${CLUSTER_CIDR}
    vlan-raw-device ${BOND}
    mtu ${MTU}
EOF

cat >>/etc/network/interfaces <<EOF

auto ${VM_BR}
iface ${VM_BR} inet manual
    bridge-ports ${BOND}
    bridge-stp off
    bridge-fd 0
    bridge-vlan-aware yes
    bridge-vids ${VLAN_PUBLIC_ID}
    mtu ${MTU}
EOF

ifreload -a
echo "[OK] network applied"
```

---

## 2) Bootstrap Ceph on **node1** – `ceph_bootstrap_node1.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail

PUBLIC_NETWORK="213.123.2.0/24"
CLUSTER_NETWORK="192.168.2.0/24"
CEPH_VERSION=""   # leave empty for Proxmox default (recommended)

if [[ -n "$CEPH_VERSION" ]]; then
  pveceph install --version "$CEPH_VERSION"
else
  pveceph install
fi

pveceph init --network "${PUBLIC_NETWORK}" --cluster-network "${CLUSTER_NETWORK}"
pveceph mon create
pveceph mgr create

echo "[OK] Ceph initialised on node1"
```

---

## 3) Add MON+MGR on **node2** and **node3** – `ceph_join_node.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail
CEPH_VERSION=""
if [[ -n "$CEPH_VERSION" ]]; then
  pveceph install --version "$CEPH_VERSION"
else
  pveceph install
fi
pveceph mon create
pveceph mgr create
echo "[OK] MON+MGR created on this node"
```

Run that on node2 and node3 (after the Proxmox cluster is formed and `/etc/pve` is in sync).

---

## 4) OSDs: 3 data + 1 metadata per node – `ceph_osds.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail

# DANGER: wipes the listed devices.
DATA_DISKS=(/dev/sdb /dev/sdc /dev/sdd)   # 3x HDD/SATA/SAS
META_DEVICE="/dev/nvme1n1"                # single fast SSD/NVMe for DB/WAL
DB_PART_SIZE_GB="50"                       # ~50G DB per OSD is a sane start; adjust to suit

confirm() {
  read -r -p "This will DESTROY data on ${DATA_DISKS[*]} and partition ${META_DEVICE}. Type 'yes' to continue: " ans
  [[ "$ans" == "yes" ]]
}

pkg(){ dpkg -s "$1" >/dev/null 2>&1 || { apt-get update -y; apt-get install -y "$1"; }; }
pkg lvm2; pkg gdisk; pkg util-linux

confirm || { echo "Aborted"; exit 1; }

echo "[*] Zapping data disks..."
for d in "${DATA_DISKS[@]}"; do
  sgdisk --zap-all "$d" || true
  wipefs -af "$d" || true
  dd if=/dev/zero of="$d" bs=1M count=10 status=none || true
done

echo "[*] Preparing metadata device ${META_DEVICE}..."
sgdisk --zap-all "${META_DEVICE}" || true
wipefs -af "${META_DEVICE}" || true

num="${#DATA_DISKS[@]}"
if [[ -z "${DB_PART_SIZE_GB}" ]]; then
  # even split across OSDs
  size_bytes=$(blockdev --getsize64 "${META_DEVICE}")
  per=$(( size_bytes / num ))
  start=2048
  for i in $(seq 1 "$num"); do
    end=$(( start + (per/512) - 1 ))
    sgdisk -n ${i}:${start}:${end} -t ${i}:8300 "${META_DEVICE}"
    start=$(( end + 1 ))
  done
else
  for i in $(seq 1 "$num"); do
    sgdisk -n ${i}:0:+${DB_PART_SIZE_GB}G -t ${i}:8300 "${META_DEVICE}"
  done
fi
partprobe "${META_DEVICE}"

echo "[*] Creating OSDs (BlueStore with DB/WAL on ${META_DEVICE})..."
idx=1
for d in "${DATA_DISKS[@]}"; do
  dbp="${META_DEVICE}p${idx}"
  echo "  -> Data ${d}  DB/WAL ${dbp}"
  pveceph osd create "${d}" -db_dev "${dbp}"
  idx=$((idx+1))
done

echo "[OK] OSDs created on this node"
```

---

## 5) Run order (succinct)

1. On **each node**: run that node’s `network_setup_*.sh`.
    
2. Form your **Proxmox cluster** (pvecm create/join).
    
3. On **node1**: `ceph_bootstrap_node1.sh`.
    
4. On **node2** & **node3**: `ceph_join_node.sh`.
    
5. On **each node**: `ceph_osds.sh`.
    
6. In the GUI: add a Ceph pool (e.g., size=3/min=2), then add Datacenter → Storage → RBD.
    

---

## Quick validation

- LACP up: `cat /proc/net/bonding/bond0`
    
- VLAN IPs: `ip -br a | egrep 'bond0\.141|bond0\.1922'`
    
- Ceph OK: `ceph -s` and `ceph osd tree`
    
- MTU path: `ping -M do -s 8972 192.168.2.12` (adjust target per node)
    

If you want me to pre-bake different NIC names or different disk paths, say the word and I’ll drop in tailored variants.