This is a clean, repeatable way to bring up your three Proxmox nodes with bonded 25 GbE, VLAN trunks (public=141, cluster=1922), and Ceph with three HDD OSDs plus one SSD/NVMe for BlueStore DB/WAL. I’ve split it into small, idempotent scripts you can drop onto each node.

> Heads-up: The OSD script **wipes the listed disks**. Read the variables at the top of each script and set them for each node before running.

---

## 1) Bond + VLAN trunk + IPs (ifupdown2 + Linux bridge)

Use this to configure a LACP bond across your two 25 Gb ports, create VLAN sub-interfaces for public (VLAN 141) and cluster (VLAN 1922), and (optionally) expose a bridge for VM traffic on the public VLAN.

```bash
#!/usr/bin/env bash
# network_setup.sh
set -euo pipefail

# ====== EDIT FOR EACH NODE ======
IFACE1="ens1f0"           # first 25G NIC
IFACE2="ens1f1"           # second 25G NIC
MTU="9000"                # jumbo frames (match your switch)
BOND="bond0"
BOND_MODE="802.3ad"       # LACP
BOND_MIIMON="100"
BOND_XMIT_HASH="layer3+4"

VLAN_PUBLIC_ID="141"
VLAN_CLUSTER_ID="1922"

# Management/public IP on VLAN 141 for THIS node:
PUBLIC_CIDR="213.123.2.101/24"   # node1 example; node2 .102, node3 .103
PUBLIC_GW="213.123.2.1"

# Cluster / Ceph backend IP on VLAN 1922 for THIS node:
CLUSTER_CIDR="192.168.2.11/24"   # node1 example; node2 .12, node3 .13

# Optional VM bridge on public VLAN (comment out to disable)
CREATE_PUBLIC_BRIDGE="yes"
VM_BR="vmbr141"
# =================================

require_pkg() {
  if ! dpkg -s "$1" >/dev/null 2>&1; then
    apt-get update -y
    apt-get install -y "$1"
  fi
}

echo "[*] Installing ifupdown2…"
require_pkg ifupdown2

echo "[*] Backing up /etc/network/interfaces"
cp -a /etc/network/interfaces /etc/network/interfaces.bak.$(date +%F-%H%M%S)

cat >/etc/network/interfaces <<EOF
source /etc/network/interfaces.d/*

auto lo
iface lo inet loopback

# 25G physical ports (no IPs here)
allow-hotplug ${IFACE1}
iface ${IFACE1} inet manual
    mtu ${MTU}

allow-hotplug ${IFACE2}
iface ${IFACE2} inet manual
    mtu ${MTU}

# LACP bond
auto ${BOND}
iface ${BOND} inet manual
    bond-slaves ${IFACE1} ${IFACE2}
    bond-miimon ${BOND_MIIMON}
    bond-mode ${BOND_MODE}
    bond-xmit-hash-policy ${BOND_XMIT_HASH}
    mtu ${MTU}
    lacp-rate fast

# VLAN for Public (Ceph public / management)
auto ${BOND}.${VLAN_PUBLIC_ID}
iface ${BOND}.${VLAN_PUBLIC_ID} inet static
    address ${PUBLIC_CIDR}
    gateway ${PUBLIC_GW}
    vlan-raw-device ${BOND}
    mtu ${MTU}

# VLAN for Cluster (Ceph cluster/backend)
auto ${BOND}.${VLAN_CLUSTER_ID}
iface ${BOND}.${VLAN_CLUSTER_ID} inet static
    address ${CLUSTER_CIDR}
    vlan-raw-device ${BOND}
    mtu ${MTU}
EOF

if [[ "${CREATE_PUBLIC_BRIDGE}" == "yes" ]]; then
cat >>/etc/network/interfaces <<EOF

# Optional VLAN-aware bridge for VMs on public VLAN
auto ${VM_BR}
iface ${VM_BR} inet manual
    bridge-ports ${BOND}
    bridge-stp off
    bridge-fd 0
    bridge-vlan-aware yes
    bridge-vids ${VLAN_PUBLIC_ID}
    mtu ${MTU}
EOF
fi

echo "[*] Applying network config (ifreload -a)…"
ifreload -a
echo "[+] Network configured."
```

Why this layout:

- Proxmox supports VLAN-aware bridges and LACP bonds; using ifupdown2 keeps everything in `/etc/network/interfaces` and is the recommended path. ([Proxmox VE](https://pve.proxmox.com/wiki/Network_Configuration?utm_source=chatgpt.com "Network Configuration"))
    

---

## 2) Bootstrap Ceph on node 1 (public + cluster networks)

Run this **only on the first node** to install Ceph, initialise the cluster with your public and cluster subnets, and create the first MON and MGR.

```bash
#!/usr/bin/env bash
# ceph_bootstrap_node1.sh
set -euo pipefail

# ====== EDIT ======
PUBLIC_NETWORK="213.123.2.0/24"    # VLAN 141
CLUSTER_NETWORK="192.168.2.0/24"   # VLAN 1922
CEPH_VERSION=""                    # leave empty for Proxmox default, or set e.g. "quincy" or "reef"
# ===================

echo "[*] Installing Ceph packages…"
if [[ -n "$CEPH_VERSION" ]]; then
  pveceph install --version "$CEPH_VERSION"
else
  pveceph install
fi

echo "[*] Initialising Ceph with public + cluster networks…"
pveceph init --network "${PUBLIC_NETWORK}" --cluster-network "${CLUSTER_NETWORK}"

echo "[*] Creating monitor and manager on this node…"
pveceph mon create
pveceph mgr create

echo "[+] Ceph bootstrap complete on node1."
```

- `pveceph init` accepts both `--network` (public) and `--cluster-network` to split client/public vs. replication traffic, which is the pattern you’re after. ([Proxmox VE](https://pve.proxmox.com/wiki/Full_Mesh_Network_for_Ceph_Server?utm_source=chatgpt.com "Full Mesh Network for Ceph Server"))
    

---

## 3) Join nodes 2 & 3 to the Ceph cluster (MON+MGR)

Run this on **each of the two remaining nodes** after they’ve joined the Proxmox cluster (so `/etc/pve` is shared).

```bash
#!/usr/bin/env bash
# ceph_join_node.sh
set -euo pipefail

CEPH_VERSION=""

echo "[*] Installing Ceph packages…"
if [[ -n "$CEPH_VERSION" ]]; then
  pveceph install --version "$CEPH_VERSION"
else
  pveceph install
fi

echo "[*] Creating monitor and manager on this node…"
pveceph mon create
pveceph mgr create

echo "[+] Ceph services added on this node."
```

---

## 4) Prepare OSDs: 3 data HDDs + 1 metadata SSD/NVMe (DB/WAL)

This script zaps the listed data disks, slices the metadata SSD into equal partitions (one per data disk), and creates BlueStore OSDs with DB/WAL on the SSD. It uses Proxmox’s `pveceph osd create` with `-db_dev` (WAL colocates with DB unless specified). ([Proxmox VE](https://pve.proxmox.com/pve-docs/pveceph.1.html?utm_source=chatgpt.com "pveceph(1)"))

```bash
#!/usr/bin/env bash
# ceph_osds.sh
set -euo pipefail

# ====== EDIT FOR EACH NODE ======
# Three data disks (HDD/SATA/SAS) that will be fully WIPED
DATA_DISKS=(/dev/sdb /dev/sdc /dev/sdd)

# One fast SSD/NVMe for DB/WAL (will be partitioned)
META_DEVICE="/dev/nvme1n1"

# Optional: size per DB partition (e.g., 50G). Leave empty for auto-split equal.
DB_PART_SIZE_GB="50"
# =================================

confirm() {
  read -r -p "This will DESTROY data on ${DATA_DISKS[*]} and partition ${META_DEVICE}. Continue? (yes/NO) " ans
  [[ "$ans" == "yes" ]]
}

require_pkg() {
  if ! dpkg -s "$1" >/dev/null 2>&1; then
    apt-get update -y
    apt-get install -y "$1"
  fi
}

echo "[*] Verifying dependencies…"
require_pkg lvm2
require_pkg gdisk

if ! confirm; then
  echo "Aborted."
  exit 1
fi

echo "[*] Wiping data disks…"
for d in "${DATA_DISKS[@]}"; do
  sgdisk --zap-all "$d"
  wipefs -af "$d" || true
  dd if=/dev/zero of="$d" bs=1M count=10 status=none
done

echo "[*] Partitioning metadata device ${META_DEVICE}…"
# Wipe meta device label first
sgdisk --zap-all "${META_DEVICE}"
wipefs -af "${META_DEVICE}" || true

num="${#DATA_DISKS[@]}"

if [[ -z "${DB_PART_SIZE_GB}" ]]; then
  # Evenly split device
  sgdisk -n 1:0:+0 -t 1:8300 "${META_DEVICE}" >/dev/null 2>&1 || true
  size_bytes=$(blockdev --getsize64 "${META_DEVICE}")
  per=$(( size_bytes / num ))
  sgdisk --zap-all "${META_DEVICE}"
  start=2048
  for i in $(seq 1 "$num"); do
    end=$(( start + (per/512) - 1 ))
    sgdisk -n ${i}:${start}:${end} -t ${i}:8300 "${META_DEVICE}"
    start=$(( end + 1 ))
  done
else
  # Fixed-size partitions
  sgdisk --zap-all "${META_DEVICE}"
  start=0
  for i in $(seq 1 "$num"); do
    sgdisk -n ${i}:${start}:+${DB_PART_SIZE_GB}G -t ${i}:8300 "${META_DEVICE}"
    start=0
  done
fi
partprobe "${META_DEVICE}"

echo "[*] Creating OSDs with DB/WAL on metadata partitions…"
idx=1
for d in "${DATA_DISKS[@]}"; do
  dbp="${META_DEVICE}p${idx}"
  echo "  - Data: ${d}  DB/WAL: ${dbp}"
  # pveceph will handle ceph-volume and BlueStore; -db_dev places DB (and WAL if not otherwise specified) on the SSD
  pveceph osd create "${d}" -db_dev "${dbp}"
  idx=$((idx+1))
done

echo "[+] OSD creation complete on this node."
```

> Note: Proxmox’s `pveceph osd create <device> -db_dev <device>` is the supported CLI for BlueStore DB/WAL placement; WAL defaults to the DB device unless `-wal_dev` is provided separately. If you prefer using `ceph-volume` directly, you can adapt this, but sticking with `pveceph` is simplest on PVE. ([Proxmox VE](https://pve.proxmox.com/pve-docs/pveceph.1.html?utm_source=chatgpt.com "pveceph(1)"))

---

## 5) Quick run order

On each node:

1. Edit and run `network_setup.sh`.
    

On node 1:  
2) Edit and run `ceph_bootstrap_node1.sh`.

On nodes 2 & 3:  
3) Run `ceph_join_node.sh`.

On **each** node:  
4) Edit and run `ceph_osds.sh` to provision its three OSDs with the single metadata SSD/NVMe.

Finally (from any node):  
5) Create pools/replicas as desired (e.g., from the GUI) and add the Ceph storage to Datacenter → Storage.

---

## Notes & tips

- Make sure your switch ports are configured as an **LACP trunk** with VLANs **141** and **1922** tagged, MTU matching the host settings. Proxmox’s VLAN-aware bridges let you keep a single bridge and tag per-VM. ([Proxmox VE](https://pve.proxmox.com/wiki/Network_Configuration?utm_source=chatgpt.com "Network Configuration"))
    
- Splitting `--network` (public) and `--cluster-network` (backend) is the recommended Ceph design to keep replication off the public VLAN. ([Ceph Documentation](https://docs.ceph.com/en/reef/rados/configuration/network-config-ref?utm_source=chatgpt.com "Network Configuration Reference - Ceph Documentation"))
    
- You can repeat the OSD script on replacement disks; it’s safe to run per-disk as needed.