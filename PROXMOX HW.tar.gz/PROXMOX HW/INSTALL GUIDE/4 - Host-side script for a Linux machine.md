Got you. Here’s a host-side script for a Linux machine running VirtualBox that creates two VLAN sub-interfaces on your physical NIC, builds two Linux bridges (one per VLAN), and (optionally) gives the host an IP on each so you can ping/SSH in. It’s idempotent and installs a tiny systemd service so it reapplies on boot without fighting NetworkManager.

### 1) Create the VLAN + bridge fabric on the host

Save as `vbox_vlan_bridges.sh` and run with sudo. Adjust the `PHYS_IF` and optional host IPs if needed.

```bash
#!/usr/bin/env bash
set -euo pipefail

# ---------- EDIT ME ----------
PHYS_IF="enp3s0"          # your host's real NIC that carries the VLAN trunk
VLAN_PUBLIC=141
VLAN_CLUSTER=1922
BR_PUBLIC="br-public"
BR_CLUSTER="br-cluster"
MTU="9000"                # or 1500 if you prefer

# Optional host IPs (uncomment to assign)
HOST_PUBLIC_IP="213.123.2.1/24"     # e.g. host acts as gateway for lab
HOST_CLUSTER_IP="192.168.2.1/24"
# --------------------------------

die(){ echo "ERROR: $*" >&2; exit 1; }

require() { command -v "$1" >/dev/null 2>&1 || die "Missing $1. Install iproute2 & systemd."; }

require ip
require sysctl

echo "[*] Enabling VLAN module…"
modprobe 8021q || true

echo "[*] Bumping MTU and (optionally) promiscuous on ${PHYS_IF}…"
ip link set dev "${PHYS_IF}" up
ip link set dev "${PHYS_IF}" mtu "${MTU}" || true
ip link set dev "${PHYS_IF}" promisc on || true

# Create VLAN links if they don't exist
for VID in "${VLAN_PUBLIC}" "${VLAN_CLUSTER}"; do
  VIF="${PHYS_IF}.${VID}"
  if ! ip link show "${VIF}" >/dev/null 2>&1; then
    echo "[*] Creating VLAN ${VID} on ${PHYS_IF} -> ${VIF}"
    ip link add link "${PHYS_IF}" name "${VIF}" type vlan id "${VID}"
  else
    echo "[=] VLAN ${VID} already exists"
  fi
  ip link set dev "${VIF}" mtu "${MTU}" || true
  ip link set dev "${VIF}" up
done

# Helper to (idempotently) create a bridge and enslave an interface
mkbridge() {
  local BR="$1" IFACE="$2"
  if ! ip link show "$BR" >/dev/null 2>&1; then
    echo "[*] Creating bridge $BR"
    ip link add name "$BR" type bridge
  else
    echo "[=] Bridge $BR already exists"
  fi
  # Ensure the member is enslaved
  if ! bridge link show | grep -q "master $BR .* ${IFACE}\b"; then
    echo "[*] Adding $IFACE to $BR"
    ip link set dev "$IFACE" master "$BR"
  else
    echo "[=] $IFACE already a member of $BR"
  fi
  ip link set dev "$BR" mtu "${MTU}" || true
  ip link set dev "$BR" up
}

mkbridge "${BR_PUBLIC}"  "${PHYS_IF}.${VLAN_PUBLIC}"
mkbridge "${BR_CLUSTER}" "${PHYS_IF}.${VLAN_CLUSTER}"

# Optional host IPs on the bridges
if [[ -n "${HOST_PUBLIC_IP:-}" ]]; then
  if ! ip address show dev "${BR_PUBLIC}" | grep -q "${HOST_PUBLIC_IP%/*}"; then
    echo "[*] Assigning ${HOST_PUBLIC_IP} to ${BR_PUBLIC}"
    ip addr add "${HOST_PUBLIC_IP}" dev "${BR_PUBLIC}" || true
  else
    echo "[=] ${BR_PUBLIC} already has ${HOST_PUBLIC_IP}"
  fi
fi

if [[ -n "${HOST_CLUSTER_IP:-}" ]]; then
  if ! ip address show dev "${BR_CLUSTER}" | grep -q "${HOST_CLUSTER_IP%/*}"; then
    echo "[*] Assigning ${HOST_CLUSTER_IP} to ${BR_CLUSTER}"
    ip addr add "${HOST_CLUSTER_IP}" dev "${BR_CLUSTER}" || true
  else
    echo "[=] ${BR_CLUSTER} already has ${HOST_CLUSTER_IP}"
  fi
fi

# Persist via a simple systemd oneshot that replays this script at boot
SERVICE_PATH="/etc/systemd/system/vbox-vlan-bridges.service"
SCRIPT_PATH="/usr/local/sbin/vbox-vlan-bridges-apply.sh"

if [[ ! -f "${SCRIPT_PATH}" ]]; then
  echo "[*] Installing persistent apply script at ${SCRIPT_PATH}"
  install -m 0755 /dev/stdin "${SCRIPT_PATH}" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
# Re-run the same steps as the main script, but compact and tolerant.

PHYS_IF="enp3s0"
VLAN_PUBLIC=141
VLAN_CLUSTER=1922
BR_PUBLIC="br-public"
BR_CLUSTER="br-cluster"
MTU="9000"
HOST_PUBLIC_IP="213.123.2.1/24"
HOST_CLUSTER_IP="192.168.2.1/24"

modprobe 8021q || true
ip link set dev "${PHYS_IF}" up || true
ip link set dev "${PHYS_IF}" mtu "${MTU}" || true
ip link set dev "${PHYS_IF}" promisc on || true

for VID in "${VLAN_PUBLIC}" "${VLAN_CLUSTER}"; do
  VIF="${PHYS_IF}.${VID}"
  ip link show "${VIF}" >/dev/null 2>&1 || ip link add link "${PHYS_IF}" name "${VIF}" type vlan id "${VID}"
  ip link set dev "${VIF}" mtu "${MTU}" || true
  ip link set dev "${VIF}" up || true
done

ip link show br-public   >/dev/null 2>&1 || ip link add name br-public type bridge
ip link show br-cluster  >/dev/null 2>&1 || ip link add name br-cluster type bridge

ip link set dev "${PHYS_IF}.${VLAN_PUBLIC}"  master br-public   || true
ip link set dev "${PHYS_IF}.${VLAN_CLUSTER}" master br-cluster  || true

ip link set dev br-public up || true
ip link set dev br-cluster up || true
ip link set dev br-public mtu "${MTU}" || true
ip link set dev br-cluster mtu "${MTU}" || true

[[ -n "${HOST_PUBLIC_IP}"  ]] && ip addr add "${HOST_PUBLIC_IP}"  dev br-public  2>/dev/null || true
[[ -n "${HOST_CLUSTER_IP}" ]] && ip addr add "${HOST_CLUSTER_IP}" dev br-cluster 2>/dev/null || true
EOF
fi

if [[ ! -f "${SERVICE_PATH}" ]]; then
  echo "[*] Installing systemd service ${SERVICE_PATH}"
  install -m 0644 /dev/stdin "${SERVICE_PATH}" <<EOF
[Unit]
Description=VirtualBox VLAN bridges (public ${VLAN_PUBLIC}, cluster ${VLAN_CLUSTER})
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=${SCRIPT_PATH}
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable --now vbox-vlan-bridges.service
else
  systemctl restart vbox-vlan-bridges.service
fi

echo "[✓] VLAN bridges ready:"
ip -br link | egrep '(^br-|'"${PHYS_IF}"'\.)' || true
```

### 2) (Optional) Cleanup script

If you want to tear the lab down cleanly:

```bash
#!/usr/bin/env bash
set -euo pipefail
PHYS_IF="enp3s0"
BR_PUBLIC="br-public"
BR_CLUSTER="br-cluster"

systemctl disable --now vbox-vlan-bridges.service 2>/dev/null || true
rm -f /etc/systemd/system/vbox-vlan-bridges.service
rm -f /usr/local/sbin/vbox-vlan-bridges-apply.sh
systemctl daemon-reload

for BR in "${BR_PUBLIC}" "${BR_CLUSTER}"; do
  ip link set dev "${BR}" down 2>/dev/null || true
  ip link del "${BR}" type bridge 2>/dev/null || true
done

for VIF in "${PHYS_IF}.141" "${PHYS_IF}.1922"; do
  ip link set dev "${VIF}" down 2>/dev/null || true
  ip link del "${VIF}" 2>/dev/null || true
done

ip link set dev "${PHYS_IF}" promisc off 2>/dev/null || true
echo "[✓] Cleaned up."
```

### 3) Attach your Proxmox VMs in VirtualBox

For each PVE VM:

- **Adapter 1** → **Bridged Adapter**, **Name:** `br-public`, **Promiscuous Mode:** _Allow All_, **Adapter Type:** _Intel PRO/1000 MT Server_
    
- **Adapter 2** → **Bridged Adapter**, **Name:** `br-cluster`, **Promiscuous Mode:** _Allow All_
    

Inside the PVE VM, keep your existing config but use a bond mode that doesn’t require LACP (e.g. `balance-xor` or `active-backup`) if you plan to bond the two vNICs.

Want me to bundle these into another ZIP like last time?