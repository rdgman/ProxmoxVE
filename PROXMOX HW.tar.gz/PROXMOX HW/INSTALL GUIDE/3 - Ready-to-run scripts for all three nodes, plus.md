Nice. I’ve bundled everything into ready-to-run scripts for all three nodes, plus a README.

- [Download the scripts (ZIP)](sandbox:/mnt/data/proxmox_ceph_3node_setup.zip)
    
[[proxmox_ceph_3node_setup.zip]]

Run order (short + sweet):

1. On each node: run its `network_setup_node*.sh`.
    
2. Form your Proxmox cluster.
    
3. On node1: `ceph_bootstrap_node1.sh`.
    
4. On node2 & node3: `ceph_join_node.sh`.
    
5. On each node: `ceph_osds.sh` (⚠️ wipes `/dev/sdb /dev/sdc /dev/sdd`; uses `/dev/nvme1n1` for DB/WAL).
    

Want me to swap NIC names, MTU, or disk paths before you roll it out?!

[[proxmox_ceph_3node_setup.zip]]