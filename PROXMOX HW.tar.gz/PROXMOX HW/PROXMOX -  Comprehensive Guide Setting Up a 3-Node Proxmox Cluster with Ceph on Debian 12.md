
# Comprehensive Guide: Setting Up a 3-Node Proxmox Cluster with Ceph on Debian 12

This guide provides a detailed, step-by-step walkthrough for deploying a robust, high-availability Proxmox VE cluster on three physical servers running Debian 12. The end result will be a hyper-converged infrastructure (HCI) where the Proxmox nodes also provide distributed, resilient storage using Ceph with 8 disks per host.

## **Part 1: Prerequisites and Core Concepts**

Before we begin, it's important to understand the components and have the necessary hardware.

- **Proxmox VE:** An open-source server virtualization management platform. It tightly integrates KVM hypervisor and LXC containers.
    
- **Ceph:** A distributed, software-defined storage system. It provides block, file, and object storage from a single, unified cluster. In our setup, it will provide resilient storage for our VMs.
    
- **Hyper-Converged Infrastructure (HCI):** A setup where the compute (Proxmox) and storage (Ceph) components run on the same physical servers, simplifying management and reducing costs.
    

### **Hardware Requirements (Per Node):**

- Three identical (or very similar) physical servers.
    
- Debian 12 installed on a dedicated boot drive on each server.
    
- A minimum of two network interfaces per server: one for Proxmox management and one for Ceph cluster traffic.
    
- 8 additional storage drives (HDD or SSD) per server, which will be dedicated entirely to Ceph. **All data on these drives will be destroyed.**
    

## **Part 2: Initial Host Preparation (Run on all 3 nodes)**

This section ensures all nodes are correctly configured to communicate with each other.

### **Step 1: Configure Static Networking**

A stable network configuration is critical. We will configure both the management and the dedicated Ceph cluster networks.

1. **Edit the network configuration file:**
    
    ```
    sudo nano /etc/network/interfaces
    ```
    
2. **Set up the static IPs.** Assign a unique IP to each node for both networks.
    
    ```
    # Management Network (for Proxmox UI, SSH, and VM traffic)
    auto enp1s0
    iface enp1s0 inet static
        address 192.168.1.11/24
        gateway 192.168.1.1
    
    # Ceph Cluster Network (for Ceph's internal replication and heartbeat traffic)
    auto enp2s0
    iface enp2s0 inet static
        address 10.10.10.11/24
    ```
    
    - **Node 1:** `192.168.1.11` and `10.10.10.11`
        
    - **Node 2:** `192.168.1.12` and `10.10.10.12`
        
    - **Node 3:** `192.168.1.13` and `10.10.10.13`
        

### **Step 2: Configure Hostname Resolution**

The cluster nodes must be able to resolve each other's names. Edit the `/etc/hosts` file to include all nodes in the cluster.

```
127.0.0.1       localhost
192.168.1.11    pve1.proxmox.local pve1
192.168.1.12    pve2.proxmox.local pve2
192.168.1.13    pve3.proxmox.local pve3
```

## **Part 3: Proxmox VE Installation (Run on all 3 nodes)**

Now we will install the Proxmox VE packages.

1. **Add the Proxmox VE repository:**
    
    ```
    echo "deb [arch=amd64] http://download.proxmox.com/debian/pve bookworm pve-no-subscription" | sudo tee /etc/apt/sources.list.d/pve-install-repo.list
    ```
    
2. **Add the GPG key for the repository:**
    
    ```
    wget https://enterprise.proxmox.com/debian/proxmox-release-bookworm.gpg -O /etc/apt/trusted.gpg.d/proxmox-release-bookworm.gpg
    ```
    
3. **Perform a full system upgrade:**
    
    ```
    sudo apt update && sudo apt full-upgrade -y
    ```
    
4. **Install the Proxmox VE packages:**
    
    ```
    sudo apt install proxmox-ve postfix open-iscsi -y
    ```
    
    _During the Postfix installation, select 'Local only' when prompted._
    
5. **Reboot each node.** After rebooting, you can access the Proxmox web interface at `https://<your_ip>:8006`. Log in as `root` with your system password.
    

## **Part 4: Creating the Proxmox Cluster**

This process joins the three individual nodes into a single, centrally managed cluster.

1. **On the first node (pve1), create the cluster.** Use the command line:
    
    ```
    pvecm create MyCluster
    ```
    
2. **On the second and third nodes (pve2, pve3), join the cluster.** Use the IP of the first node:
    
    ```
    pvecm add 192.168.1.11
    ```
    
    You will be prompted for the root password of the first node to authorize the join.
    

After a few moments, you will see all three nodes appear in the web interface under the "Datacenter" view.

## **Part 5: Ceph Storage Setup**

This is where we configure the hyper-converged storage backend.

### **Step 1: Disk Preparation (Run on all 3 nodes)**

Ceph requires full control over its disks. The following script will wipe the partition tables from the 8 storage drives on each host.

**`prepare_ceph_disks.sh`**

```
#!/bin/bash
# WARNING: ALL DATA ON THE SPECIFIED DISKS WILL BE PERMANENTLY DESTROYED.
DISKS=(
    "/dev/sdb" "/dev/sdc" "/dev/sdd" "/dev/sde"
    "/dev/sdf" "/dev/sdg" "/dev/sdh" "/dev/sdi"
)

echo "This script will wipe all data on the specified disks."
read -p "Are you sure you want to continue? (yes/no): " CONFIRMATION
if [ "$CONFIRMATION" != "yes" ]; then
    echo "Aborting."
    exit 1
fi

for disk in "${DISKS[@]}"; do
    if [ -b "$disk" ]; then
        echo "Wiping partition table on ${disk}..."
        sudo sgdisk --zap-all "$disk"
        echo "Successfully wiped ${disk}."
    else
        echo "Disk ${disk} not found. Skipping."
    fi
done
echo "Disk preparation complete."
```

_Save this script, make it executable (`chmod +x prepare_ceph_disks.sh`), and run it with `sudo ./prepare_ceph_disks.sh` on each of the three nodes._

### **Step 2: Ceph Installation and Configuration (Web Interface)**

1. **Install Ceph:** On each node in the web UI, go to `Ceph` -> `Installation`, select the "Reef" release, and click `Start installation`.
    
2. **Create Initial Configuration:** On **one node only**, go to `Ceph` -> `Configuration`.
    
    - Set the **Public Network** to your management network (`192.168.1.0/24`).
        
    - Set the **Cluster Network** to your dedicated Ceph network (`10.10.10.0/24`). This is crucial for performance.
        
    - Add the other two nodes as Monitors and Managers. A 3-monitor setup is ideal for maintaining a quorum.
        
3. **Create OSDs (Object Storage Daemons):** An OSD is a daemon that manages a single storage disk.
    
    - On each node, navigate to `Ceph` -> `OSDs`.
        
    - Click `Create: OSD`.
        
    - Select the 8 disks you wiped earlier and create the OSDs. Repeat this on all three nodes until all 24 disks are part of the Ceph cluster.
        
4. **Create a Ceph Pool:** A pool is a logical partition where you store data.
    
    - Go to `Ceph` -> `Pools` and click `Create`.
        
    - **Name:** `vm-storage`
        
    - **Size:** `3`. This means Ceph will keep 3 copies of your data across different nodes for redundancy.
        
    - **Min. Size:** `2`. This allows the pool to remain operational for writes even if one node is down.
        
    - Click `Create`.
        

## **Part 6: Integrating Ceph Storage with Proxmox**

The final step is to make the Ceph pool available as storage for Proxmox.

1. In the web UI, go to `Datacenter` -> `Storage` -> `Add`.
    
2. From the dropdown, select `RBD` (RADOS Block Device).
    
3. **ID:** Give it a descriptive name, like `ceph-storage`.
    
4. **Pool:** Select the `vm-storage` pool you created.
    
5. Ensure the "Enable" box is checked and click `Add`.
    

You now have a fully functional 3-node Proxmox cluster with a hyper-converged, high-availability Ceph storage backend. You can begin creating virtual machines and containers, selecting `ceph-storage` as their storage location to leverage the power of your distributed storage system.