Here's a proposed bill of materials + configuration, along with suggested SSD/NVMe models suited for a Proxmox + Ceph setup on your Supermicro SYS-121H-TNR. You’ll get two boot NVMes, one for metadata/journal, and four for Ceph OSD (data). I include “premium / enterprise” options and some more cost-sensible ones.

---

## Key Design Guidelines / Requirements

Before choosing specific drives, some general rules:

| Component                      | What you want / Why                                                                                                                                                                                                 |
| ------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Boot drives**                | Need high reliability, moderate size (e.g. 250-500 GB), mirrored / RAID1 or OS-agnostic redundancy. Low write activity.                                                                                             |
| **Metadata / Journal device**  | Needs high IOPS, low latency, high endurance. Ceph performs better when metadata/journal is on separate high-quality devices.                                                                                       |
| **Ceph OSD data drives**       | Balance between capacity, endurance, cost. Depending on workload (small files vs large sequential writes vs mixed), choose SSD vs NVMe, spec (TLC, enterprise grade, etc.). Redundancy/rack awareness also matters. |
| **Form factor & connectivity** | Use the server’s internal M.2 slots for boot if speed is okay. Use front hot-swap NVMe/SATA/SAS bays for data/metadata devices. If you run out of slots, possibly use NVMe AIC (add-in cards).                      |
| **Cooling & power**            | NVMe drives run hot; ensure airflow and that the PSU can supply the extra power. Also monitor thermal throttling etc.                                                                                               |

---

## Example Configuration

Here’s one suggested configuration:

|Role|Device Count|Size / Spec Suggestion|
|---|---|---|
|Boot (Proxmox OS)|2 NVMe drives in mirrored setup|500 GB enterprise NVMe M.2 or U.2, moderate endurance (say ≥ 1-3 DWPD)|
|Metadata / Journal|1 NVMe drive (high endurance)|1-2 TB enterprise NVMe, high write endurance, good IOPS|
|Data (Ceph OSD)|4 drives|Either NVMe or high-end SSDs (SATA or U.2) with good endurance, maybe 4-8 TB each depending on capacity needs; maybe mix speed and capacity if needed|

---

## Suggested SSD/NVMe Models

Here are some good options, grouped by role. Prices are indicative and from UK / European vendors where possible. Depending on your budget, you can go “enterprise level” or “mid-tier”.

### [Solidigm D7‑P5520 1.92TB Enterprise NVMe](https://www.networkhardwares.com/products/solidigm-ssdpf2kx019t11z-sk-solidigm-d7-p5520-series-1-92tb-2-5-ssdpf2kx019t11z?variant=48047084699853&_gsid=UpQnyk7yWgCg&utm_source=chatgpt.com)

#### Enterprise High Endurance

_$329.99_

### [Solidigm D5‑P5336 30.72TB Server SSD](https://www.networkhardwares.com/products/solidigm-sbfpf2bv307top1-solidigm-ssd-sbfpf2bv307top1-d5-p5336-30-72tb-2-5-pcie4-0x4-3d5-qlc-retail?variant=47426147614925&_gsid=UpQnyk7yWgCg&utm_source=chatgpt.com)

#### Massive Capacity

_$3,149.99_

### Samsung 990 EVO Plus 2TB Gen4 NVMe

#### Good Mid‑Tier

_£64.99_

### Kingston KC3000 2TB NVMe Gen4

#### Budget SSD

_£105.00_

### WD Black SN850X 1TB Performance NVMe

#### Performance

_£70.00_

### Samsung 990 PRO 1TB Gen4/5

#### Pro / Top End

_£84.99_

### Kingston NV3 4TB Gen4 NVMe

#### Large Capacity

_£195.98_

### Sabrent Rocket 1TB Gen4

#### Budget Gen4

_£55.99_

Here are my top picks per category:

|Role|Suggested Drive|Key Specs / Pros|Approx Price & Trade-Offs|
|---|---|---|---|
|**Boot drives (x2)**|**Samsung 990 EVO Plus 2TB**|Very good Gen4 NVMe, fast, reliable. Enough space. You could also choose smaller size to save cost.|~£65-£80 for 2 TB; lower capacity models cheaper. Lower endurance than top enterprise, but acceptable for boot.|
|**Metadata / Journal**|**[Solidigm D7‑P5520 1.92TB](https://www.networkhardwares.com/products/solidigm-ssdpf2kx019t11z-sk-solidigm-d7-p5520-series-1-92tb-2-5-ssdpf2kx019t11z?variant=48047084699853&_gsid=UpQnyk7yWgCg&utm_source=chatgpt.com)**|Designed for mixed workloads, high endurance. Good IOPS. Great for Ceph metadata/journal.|More expensive, but improves performance. Probably the single best upgrade item.|
|**Data OSD (x4)**|Two options: • For capacity + more modest cost, use **Kingston NV3 4TB** or **Kingston KC3000 2TB** drives. • Or higher end: **Samsung 990 PRO 1TB** or **WD Black SN850X 1TB** if you want more speed / smaller size but better performance.|Using 4 × 4 TB NVMe gives good capacity but costs more. If budget tight, mix 2 high-end + 2 capacity drives. Also, cost per TB drops with larger size but check endurance (TBW).||

---

## Enterprise NVMe Drives to Consider

Also worth looking at **Samsung PM1733**, **Solidigm D7 / D5 series**, HPE mixed use / read intensive enterprise drives:

- **Samsung PM1733**: Very high performance, high endurance, great for both metadata and data. ([Samsung Semiconductor Global](https://semiconductor.samsung.com/ssd/enterprise-ssd/pm1733/?utm_source=chatgpt.com "PM1733 | Enterprise SSD | Samsung Semiconductor Global"))
    
- **Solidigm D5-P5336**: massive capacity NVMe (30.72 TB, etc) if you need a very large data tier. ([Lenovo Press](https://lenovopress.lenovo.com/lp1300.pdf?utm_source=chatgpt.com "ThinkSystem PM1733 Entry NVMe PCIe 4.0 x4 SSDs"))
    
- **Solidigm D7-P5520**: as above in product picks; good mixed workload performance.
    

---

## Rough Cost Estimate (UK Pricing)

Here’s an approximate cost breakdown, assuming enterprise / high-end NVMe where appropriate:

|Item|Quantity|Price Each (Approx)|Total ≈|
|---|---|---|---|
|Boot drives (mid-enterprise)|2 × 500 GB NVMe|£80 each|**£160**|
|Metadata drive (enterprise)|1 × 1.92-2 TB enterprise NVMe|~£400–£600 depending on spec|**£500**|
|Data OSD drives (4 × 4 TB NVMe / SSD)|4 × (say £300 each for high performance NVMe)|~£300 × 4 = **£1,200**||
|Enterprise controller / add-in card (if needed)|0-1 depending on slot availability|Maybe ~£200-£400 if needed|**£300**|
|Misc (cables, cooling, extra fan, spare)|—|~£100|**£100**|

**Estimated Total**: **£2,000 - £3,000** depending on how “enterprise / high end” you go and whether you already have some components. If you lean more budget, using 2-3 TB drives instead, SATA SSDs, etc, could reduce cost by ~30-50%.

---

