That's an excellent script for Proxmox hostname recovery. To create a script that generates a **formatted report** of Proxmox and Ceph-related service statuses, we'll use `systemctl` for status checks and structured output formatting using `printf` and markdown-like tables.

Here is the requested monitoring and reporting script:

## 📜 Proxmox/Ceph Service Status Report Script

Bash

```
#!/bin/bash
#
# Proxmox/Ceph Service Status Reporter Script
#
# Generates a formatted report showing the status of critical
# Proxmox and Ceph services on the local node.
#

# --- Configuration ---
# List of critical services to check for Proxmox and Ceph
PVE_SERVICES=(
    pve-cluster.service
    pvestatd.service
    pveproxy.service
    pvescheduler.service
    pve-ha-lrm.service
    pve-ha-crm.service
)

CEPH_UNITS=(
    ceph-osd
    ceph-mon
    ceph-mgr
)

# --- Functions ---

# Function to get the status of a service
get_service_status() {
    local service_name="$1"
    systemctl show -p ActiveState,SubState,UnitFileState,LoadState "$service_name" | awk -F'=' '{print $2}' | tr '\n' ' '
}

# Function to format the status for the report
format_status() {
    local status_line="$1"
    local active_state=$(echo "$status_line" | awk '{print $1}')
    local sub_state=$(echo "$status_line" | awk '{print $2}')

    if [[ "$active_state" == "active" ]]; then
        echo "✅ Active ($sub_state)"
    elif [[ "$active_state" == "inactive" ]]; then
        echo "⚪ Inactive"
    elif [[ "$active_state" == "failed" ]]; then
        echo "❌ FAILED ($sub_state)"
    else
        echo "❓ $active_state ($sub_state)"
    fi
}

# --- Report Generation ---
clear
echo "=========================================================="
echo "          🚀 Proxmox/Ceph Health Status Report          "
echo "=========================================================="
echo "Host: $(hostname)"
echo "Date: $(date)"
echo "----------------------------------------------------------"

## 1. 🌐 Proxmox Cluster and Core Services Status
echo "## 1. 🌐 Proxmox Cluster and Core Services Status"
echo

# Print table header
printf "| %-20s | %-18s | %-10s |\n" "Service Name" "Status" "Load State"
printf "| %-20s | %-18s | %-10s |\n" "--------------------" "------------------" "----------"

for service in "${PVE_SERVICES[@]}"; do
    STATUS_LINE=$(get_service_status "$service" 2>/dev/null)
    
    # Check if service is loaded/found
    if [[ "$STATUS_LINE" == "not-found" ]]; then
        STATUS_FMT="⚠️ Not Installed"
        LOAD_STATE="not-found"
    else
        # Separate ActiveState, SubState, and LoadState
        ACTIVE_STATE=$(echo "$STATUS_LINE" | awk '{print $1}')
        SUB_STATE=$(echo "$STATUS_LINE" | awk '{print $2}')
        LOAD_STATE=$(echo "$STATUS_LINE" | awk '{print $3}')
        
        # Determine formatted status
        if [[ "$ACTIVE_STATE" == "active" ]]; then
            STATUS_FMT="✅ Active ($SUB_STATE)"
        elif [[ "$ACTIVE_STATE" == "inactive" ]]; then
            STATUS_FMT="⚪ Inactive"
        elif [[ "$ACTIVE_STATE" == "failed" ]]; then
            STATUS_FMT="❌ FAILED ($SUB_STATE)"
        else
            STATUS_FMT="❓ $ACTIVE_STATE ($SUB_STATE)"
        fi
    fi

    # Print table row
    printf "| %-20s | %-18s | %-10s |\n" "$service" "$STATUS_FMT" "$LOAD_STATE"
done

echo "----------------------------------------------------------"

## 2. 💾 Ceph Storage Service Status
echo
echo "## 2. 💾 Ceph Storage Service Status"
echo

# Detect the local Ceph OSD ID (if any)
OSD_ID=$(ls /var/lib/ceph/osd/ | grep "ceph" | head -1 | cut -d'-' -f2 2>/dev/null)
CEPH_UNITS_NODE=("${CEPH_UNITS[@]}")

# If OSD ID found, add the specific OSD service
if [[ -n "$OSD_ID" ]]; then
    CEPH_UNITS_NODE+=("ceph-osd@$OSD_ID.service")
    echo "Note: Checking OSD service for ID: $OSD_ID"
else
    echo "Note: No local Ceph OSD unit found."
fi

# Print table header for Ceph
printf "| %-15s | %-18s |\n" "Ceph Unit" "Status"
printf "| %-15s | %-18s |\n" "---------------" "------------------"

for unit in "${CEPH_UNITS_NODE[@]}"; do
    # For Ceph, we check for enabled status if no specific instance is running
    
    # The ceph-mon/mgr@NAME services are usually specific to the node name
    if [[ "$unit" == "ceph-mon" || "$unit" == "ceph-mgr" ]]; then
        CEPH_SERVICE_NAME="${unit}@$(hostname).service"
    elif [[ "$unit" == "ceph-osd" ]]; then
        # Skip the generic template unless it's the specific instance added above
        if [[ "$unit" != "ceph-osd@$OSD_ID.service" ]]; then
            continue
        fi
        CEPH_SERVICE_NAME="${unit}@$OSD_ID.service"
    else
        CEPH_SERVICE_NAME="$unit"
    fi

    STATUS_LINE=$(get_service_status "$CEPH_SERVICE_NAME" 2>/dev/null)

    if [[ "$STATUS_LINE" == "not-found" ]]; then
        STATUS_FMT="⚠️ Not Installed/Found"
    else
        ACTIVE_STATE=$(echo "$STATUS_LINE" | awk '{print $1}')
        SUB_STATE=$(echo "$STATUS_LINE" | awk '{print $2}')
        
        if [[ "$ACTIVE_STATE" == "active" ]]; then
            STATUS_FMT="✅ Active ($SUB_STATE)"
        elif [[ "$ACTIVE_STATE" == "inactive" ]]; then
            STATUS_FMT="⚪ Inactive"
        elif [[ "$ACTIVE_STATE" == "failed" ]]; then
            STATUS_FMT="❌ FAILED ($SUB_STATE)"
        else
            STATUS_FMT="❓ $ACTIVE_STATE ($SUB_STATE)"
        fi
    fi

    printf "| %-15s | %-18s |\n" "$CEPH_SERVICE_NAME" "$STATUS_FMT"
done

echo "----------------------------------------------------------"

## 3. 📊 Cluster and Ceph Health Summary
echo
echo "## 3. 📊 Cluster and Ceph Health Summary"
echo

# PVE Cluster Quorum Check
echo "**Proxmox Cluster Status (pvecm status):**"
if command -v pvecm &> /dev/null; then
    pvecm status | grep "Quorum"
    pvecm status | grep "Nodes"
else
    echo "Command 'pvecm' not found."
fi

# Ceph Health Check
echo
echo "**Ceph Cluster Health (ceph -s):**"
if command -v ceph &> /dev/null; then
    # Filter for key health summary lines
    ceph -s | grep -E 'health:|services:|data:|io:'
else
    echo "Command 'ceph' not found. Is 'ceph-common' installed?"
fi

# Final Check
echo
echo "--- Post-Check: Failed Systemd Units ---"
if systemctl --failed --no-pager | grep -q 'loaded units listed'; then
    echo "SUCCESS: No failed systemd units on this host."
else
    echo "⚠️ WARNING: The following services are in a failed state:"
    systemctl --failed --no-pager
fi

echo "=========================================================="
```

### How to Use the Script

1. **Save the script:** Save the code above into a file named, for example, `pve-ceph-report.sh`.
    
2. **Make it executable:** Run `chmod +x pve-ceph-report.sh`.
    
3. **Execute:** Run the script with `./pve-ceph-report.sh`.
    

### Report Explanation

The script generates a report in three sections:

1. **Proxmox Cluster and Core Services Status:** Checks essential PVE services like `pve-cluster` (the backbone filesystem), `pveproxy` (the web interface API), and HA management services.
    
    - **Status:** Shows if the service is **Active** (running), **Inactive**, **Failed**, or **Not Installed**.
        
2. **Ceph Storage Service Status:** Checks the Ceph components configured for the specific node:
    
    - **`ceph-mon` (Monitor):** Manages cluster state.
        
    - **`ceph-mgr` (Manager):** Runs metrics and external APIs.
        
    - **`ceph-osd@ID` (OSD):** The actual disk daemon used for data storage. The script automatically tries to detect and check the local OSD ID.
        
3. **Cluster and Ceph Health Summary:** Provides quick command-line output for overall cluster health:
    
    - **`pvecm status`:** Shows cluster quorum status (critical for HA and Ceph operations).
        
    - **`ceph -s`:** Shows the overall Ceph health status (e.g., HEALTH_OK, HEALTH_WARN, data usage, IO).
        
    - **Failed Systemd Units:** A final check for _any_ service that may be in a failed state.