That's a well-structured script for a complex task! The existing script is robust and covers the critical steps needed to recover a Proxmox node after an improper hostname change.

Here is the improved script, along with detailed documentation and explanation of the changes.

---

## 🚀 Proxmox Hostname Recovery Script

The key improvements focus on **handling Ceph services more dynamically**, ensuring the **`ceph-mon`** and **`ceph-osd`** services (if present) are also updated and restarted, and generally making the service restart section more comprehensive.

Bash

```
#!/bin/bash
#
# Proxmox Hostname Change Recovery Script (Improved)
#
# PURPOSE: Fixes failed services and configuration files after an improper
#          hostname change on a Proxmox VE node, including dynamic handling
#          of integrated Ceph services.
#
# ---!!! WARNING !!!---
# 1. Run this script ONLY on the node where the hostname was changed.
# 2. After running, you MUST manually update /etc/corosync/corosync.conf
#    on ALL other cluster nodes to replace the OLD hostname with the NEW one.
#
set -e

# --- 1. GATHER INFORMATION AND VALIDATION ---
echo "--- Proxmox Hostname Recovery Tool ---"
echo
CURRENT_HOSTNAME=$(hostname)

read -p "Please enter the OLD hostname: " OLD_HOSTNAME
read -p "Please enter the NEW hostname [${CURRENT_HOSTNAME}]: " NEW_HOSTNAME

# Use the current hostname if the user just presses Enter
NEW_HOSTNAME=${NEW_HOSTNAME:-$CURRENT_HOSTNAME}
NEW_HOSTNAME_LOWER=$(echo "$NEW_HOSTNAME" | tr '[:upper:]' '[:lower:]')

# Basic Input Validation
if [ -z "$OLD_HOSTNAME" ] || [ -z "$NEW_HOSTNAME" ]; then
    echo "ERROR: Both old and new hostnames are required. Exiting."
    exit 1
fi

if [ "$OLD_HOSTNAME" == "$NEW_HOSTNAME" ]; then
    echo "INFO: Old and new hostnames are the same. Nothing to do. Exiting."
    exit 0
fi

echo "----------------------------------------"
echo "Will perform the following changes:"
echo "OLD Hostname: $OLD_HOSTNAME"
echo "NEW Hostname: $NEW_HOSTNAME (used for systemctl/configs)"
echo "----------------------------------------"
read -p "Is this correct? (y/N) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Aborted."
    exit 1
fi

# --- 2. UPDATE CONFIGURATION FILES ---
echo
echo "--- 2. Configuration File Updates ---"
# Stop pve-cluster early, as it relies on the old hostname and can cause conflicts
echo "INFO: Stopping pve-cluster service to safely modify files..."
systemctl stop pve-cluster.service || true

echo "INFO: Updating /etc/hosts (crucial for local name resolution)..."
# Use word boundaries (\b) to ensure exact matches
sed -i "s/\b${OLD_HOSTNAME}\b/${NEW_HOSTNAME_LOWER}/g" /etc/hosts

echo "INFO: Updating /etc/hostname..."
echo "$NEW_HOSTNAME_LOWER" > /etc/hostname

echo "INFO: Applying new hostname to current session..."
hostnamectl set-hostname "$NEW_HOSTNAME_LOWER"

echo "INFO: Updating Postfix main.cf (for email alerts)..."
# Use the new variable name to avoid issues with potential uppercase in user input
sed -i "s/\(myhostname\s*=\s*\)${OLD_HOSTNAME}/\1${NEW_HOSTNAME_LOWER}/" /etc/postfix/main.cf

# Update Corosync config. This file is critical for cluster operations.
if [ -f /etc/corosync/corosync.conf ]; then
    echo "INFO: Updating /etc/corosync/corosync.conf..."
    # Corosync uses the hostname in its configuration lines
    sed -i "s/\b${OLD_HOSTNAME}\b/${NEW_HOSTNAME_LOWER}/g" /etc/corosync/corosync.conf
else
    echo "WARNING: /etc/corosync/corosync.conf not found. Skipping. (Standalone node?)"
fi

# --- 3. RESTART CLUSTER AND SERVICES ---
echo
echo "--- 3. Service Restart and PVE Filesystem Fixes ---"

echo "INFO: Attempting to restart the main cluster filesystem (pmxcfs)..."
systemctl start pve-cluster.service

echo "INFO: Waiting 5 seconds for pmxcfs to mount..."
sleep 5

# Critical Check: pmxcfs mount status
if ! mount | grep -q '/etc/pve'; then
    echo -e "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    echo "CRITICAL ERROR: pve-cluster service failed to start."
    echo "pmxcfs is not mounted at /etc/pve."
    echo "Please debug before continuing (systemctl status pve-cluster.service)."
    echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n"
    exit 1
fi

echo "SUCCESS: pmxcfs mounted successfully at /etc/pve."

# Rename PVE Node Configuration Directory
NODE_CONF_DIR="/etc/pve/nodes/${OLD_HOSTNAME}"
NEW_NODE_CONF_DIR="/etc/pve/nodes/${NEW_HOSTNAME_LOWER}"

if [ -d "$NODE_CONF_DIR" ]; then
    echo "INFO: Renaming node configuration directory: ${NODE_CONF_DIR} -> ${NEW_NODE_CONF_DIR}"
    mv "$NODE_CONF_DIR" "$NEW_NODE_CONF_DIR"
else
    echo "WARNING: Node configuration directory ${NODE_CONF_DIR} not found. Skipping rename."
fi

# Comprehensive list of services to restart
SERVICES_TO_RESTART=(
    pvestatd.service
    pveproxy.service
    pve-firewall.service
    pve-ha-lrm.service
    pve-ha-crm.service
    pvescheduler.service
    pve-guests.service
    postfix.service
)

echo "INFO: Restarting core Proxmox services..."
for service in "${SERVICES_TO_RESTART[@]}"; do
    echo "--> Restarting ${service}"
    # Use 'try-restart' which is safer than 'restart' if the service is not active
    systemctl try-restart "${service}" || echo "WARNING: Failed to restart ${service}. It may not be installed."
done

# --- 4. CEPH SERVICE HANDLING (IMPROVED) ---
echo
echo "--- 4. Ceph Service Handling ---"
# Ceph services are named after the hostname or an index (e.g., ceph-mon@pve)
CEPH_UNITS_TO_RESTART=(
    "ceph-mon@${OLD_HOSTNAME}.service"
    "ceph-mgr@${OLD_HOSTNAME}.service"
)

# 1. Check for old Ceph services and disable/rename them
for old_unit in "${CEPH_UNITS_TO_RESTART[@]}"; do
    if systemctl is-active "$old_unit" &> /dev/null || systemctl is-enabled "$old_unit" &> /dev/null; then
        new_unit=$(echo "$old_unit" | sed "s/${OLD_HOSTNAME}/${NEW_HOSTNAME_LOWER}/")
        echo "INFO: Disabling and stopping old Ceph unit: $old_unit"
        systemctl stop "$old_unit" || true
        systemctl disable "$old_unit" || true
        
        # If the new unit exists (i.e., renamed by Ceph itself), just enable/start it.
        # Otherwise, if it's a template, we just enable the new name
        echo "INFO: Enabling and starting new Ceph unit: $new_unit"
        systemctl daemon-reload
        systemctl enable "$new_unit" || echo "WARNING: Could not enable $new_unit. Continuing..."
        systemctl start "$new_unit" || echo "WARNING: Failed to start $new_unit."
    fi
done

# 2. Restart all OSD services (OSDs are typically named by ID, not hostname, but a restart is safe)
echo "INFO: Attempting to restart all Ceph OSDs (ceph-osd@*.service)..."
systemctl restart ceph-osd@\*.service || echo "WARNING: No ceph-osd services found to restart."


# --- 5. FINAL VERIFICATION CHECKS ---
echo
echo "--- 5. Final Verification Checks ---"

# Check 1: Failed services
echo "INFO: Checking for any remaining failed services..."
if systemctl --failed --no-pager | grep -q '0 loaded units listed'; then
    echo "SUCCESS: No failed systemd services found. (System Health: OK)"
else
    echo "ERROR: Some services are still in a failed state! Please investigate:"
    systemctl --failed --no-pager
fi

# Check 2: Cluster quorum status
echo
echo "INFO: Checking cluster status with 'pvecm status'..."
pvecm status

# Check 3: Proxmox API responsiveness
echo
echo "INFO: Checking Proxmox API responsiveness (pvesh get /nodes)..."
pvesh get /nodes

# Check 4: Ceph Health (critical for storage)
echo
echo "INFO: Checking Ceph Cluster Health (ceph -s)..."
if command -v ceph &> /dev/null; then
    ceph -s | grep "health"
else
    echo "WARNING: Ceph command not found. Cannot verify Ceph health."
fi

echo
echo "--- Recovery Attempt FINISHED ---"
echo "ATTENTION: If this is a cluster, you must now manually update /etc/corosync/corosync.conf on ALL other nodes!"
echo "Log into the PVE Web GUI and check the status of your node and VMs."
```

---

## 📘 Documentation and Explanation of Changes

The original script was primarily focused on Proxmox core services. The improved version adds a robust and dynamic check for integrated Ceph services.

|**Section**|**Original Action**|**Improvement/Explanation**|
|---|---|---|
|**Input**|Uses `NEW_HOSTNAME` as entered.|**Added `NEW_HOSTNAME_LOWER`**: Hostnames in Linux configs are generally lowercase. The script now converts the input to lowercase to prevent configuration errors.|
|**`sed` commands**|Simple substitution.|**Used `NEW_HOSTNAME_LOWER`** for consistency across configuration files like `/etc/hosts` and `/etc/hostname`.|
|**Hostname Set**|Uses `hostnamectl set-hostname "$NEW_HOSTNAME"`.|Uses **`$NEW_HOSTNAME_LOWER`** for the actual system call.|
|**PVE Dir Rename**|`mv "/etc/pve/nodes/${OLD_HOSTNAME}" "/etc/pve/nodes/${NEW_HOSTNAME}"`.|Uses **`$NEW_HOSTNAME_LOWER`** to correctly match the new system hostname.|
|**Ceph Services**|Restarts only `ceph-mgr@pve.service` (static).|**Dynamic Ceph Handling (Section 4)**: Ceph services are named `ceph-mon@<hostname>` and `ceph-mgr@<hostname>`. The script now checks for the old units, stops/disables them, and then enables/starts the correct new units (`ceph-mon/mgr@${NEW_HOSTNAME_LOWER}.service`). This ensures the monitor and manager processes correctly bind to the new node name.|
|**OSD Services**|Not specifically addressed.|**Added OSD Restart:** Explicitly restarts all OSD services (`ceph-osd@*.service`). Although OSDs are usually named by ID, restarting them ensures they reconnect and report status correctly after the host name change.|
|**PVE Services**|Restarts a hardcoded list.|**Added `pveproxy.service` and `postfix.service`** to the restart list, as the web GUI and email services are critical and rely directly on the hostname.|
|**Final Check**|Checks `ceph -s` indirectly.|**Improved Ceph Health Check:** Now checks `ceph -s|

### What the Script Does

1. **Gathers Input (Section 1):** Prompts for the old and new hostnames, then performs basic validation and converts the new hostname to lowercase for compatibility.
    
2. **Updates Configurations (Section 2):**
    
    - Stops the **`pve-cluster.service`** (which mounts the critical `/etc/pve` filesystem) to safely modify configuration files.
        
    - Updates `/etc/hosts`, `/etc/hostname`, `/etc/postfix/main.cf`, and the crucial **`/etc/corosync/corosync.conf`** using `sed` to replace the old name with the new one.
        
    - Applies the change to the running system using `hostnamectl`.
        
3. **Restarts and Fixes PVE (Section 3):**
    
    - Restarts **`pve-cluster.service`**.
        
    - **CRITICALLY** checks that the `/etc/pve` filesystem has mounted correctly. If this fails, the script aborts.
        
    - Renames the node's configuration directory under `/etc/pve/nodes/` (e.g., renames `/etc/pve/nodes/oldname` to `/etc/pve/nodes/newname`).
        
    - Restarts all necessary PVE core services.
        
4. **Handles Ceph (Section 4):**
    
    - Dynamically identifies and stops the old `ceph-mon` and `ceph-mgr` services.
        
    - Starts the new `ceph-mon` and `ceph-mgr` services, ensuring they use the new hostname.
        
    - Restarts all `ceph-osd` processes to confirm they re-establish communication with the updated monitor/manager.
        
5. **Verifies Health (Section 5):** Provides several checks to confirm recovery:
    
    - Checks for any remaining **failed systemd services**.
        
    - Verifies **Proxmox cluster quorum** status (`pvecm status`).
        
    - Tests the **Proxmox API** responsiveness (`pvesh get /nodes`).
        
    - Checks the overall **Ceph cluster health** status (`ceph -s`).

```
#old script 

#!/bin/bash
#
# Proxmox Hostname Change Recovery Script
#
# This script is designed to fix the failed services that occur after
# an improper hostname change on a Proxmox VE node.
#
# ---!!! WARNING !!!---
# Run this script ONLY on the node where the hostname was changed.
# If this is part of a cluster, you will need to manually update
# corosync.conf on other nodes.
#
set -e

# --- 1. GATHER INFORMATION ---
echo "--- Proxmox Hostname Recovery ---"
echo
CURRENT_HOSTNAME=$(hostname)

read -p "Please enter the OLD hostname: " OLD_HOSTNAME
read -p "Please enter the NEW hostname [${CURRENT_HOSTNAME}]: " NEW_HOSTNAME

# Use the current hostname if the user just presses Enter
NEW_HOSTNAME=${NEW_HOSTNAME:-$CURRENT_HOSTNAME}

if [ -z "$OLD_HOSTNAME" ] || [ -z "$NEW_HOSTNAME" ]; then
    echo "ERROR: Both old and new hostnames are required. Exiting."
    exit 1
fi

if [ "$OLD_HOSTNAME" == "$NEW_HOSTNAME" ]; then
    echo "INFO: Old and new hostnames are the same. Nothing to do. Exiting."
    exit 0
fi

echo "----------------------------------------"
echo "Will perform the following change:"
echo "OLD: $OLD_HOSTNAME"
echo "NEW: $NEW_HOSTNAME"
echo "----------------------------------------"
read -p "Is this correct? (y/N) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Aborted."
    exit 1
fi

# --- 2. UPDATE CONFIGURATION FILES ---
echo
echo "INFO: Stopping pve-cluster service to be safe..."
systemctl stop pve-cluster.service || true # It's likely already stopped

echo "INFO: Updating /etc/hosts..."
sed -i "s/\b${OLD_HOSTNAME}\b/${NEW_HOSTNAME}/g" /etc/hosts

echo "INFO: Updating /etc/hostname..."
echo "$NEW_HOSTNAME" > /etc/hostname

echo "INFO: Updating Postfix main.cf..."
sed -i "s/\(myhostname\s*=\s*\)${OLD_HOSTNAME}/\1${NEW_HOSTNAME}/" /etc/postfix/main.cf

# The key file for the cluster filesystem
if [ -f /etc/corosync/corosync.conf ]; then
    echo "INFO: Updating /etc/corosync/corosync.conf..."
    sed -i "s/\b${OLD_HOSTNAME}\b/${NEW_HOSTNAME}/g" /etc/corosync/corosync.conf
else
    echo "WARNING: /etc/corosync/corosync.conf not found. Skipping."
fi

# --- 3. RESTART SERVICES ---
echo
echo "INFO: Applying new hostname to current session..."
hostnamectl set-hostname "$NEW_HOSTNAME"

echo "INFO: Attempting to restart the main cluster filesystem..."
systemctl start pve-cluster.service

echo "INFO: Waiting 5 seconds for pmxcfs to mount..."
sleep 5

# Check if pmxcfs mounted correctly
if ! mount | grep -q '/etc/pve'; then
    echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    echo "CRITICAL ERROR: pve-cluster service failed to start."
    echo "pmxcfs is not mounted at /etc/pve."
    echo "Please run 'systemctl status pve-cluster.service' and 'journalctl -u pve-cluster.service' to debug."
    echo "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    exit 1
fi

echo "SUCCESS: pmxcfs mounted successfully at /etc/pve."

# If pmxcfs is up, we may need to rename the node directory
if [ -d "/etc/pve/nodes/${OLD_HOSTNAME}" ]; then
    echo "INFO: Renaming node configuration directory..."
    mv "/etc/pve/nodes/${OLD_HOSTNAME}" "/etc/pve/nodes/${NEW_HOSTNAME}"
fi

echo "INFO: Restarting all other PVE services..."
# List of services from your original post
SERVICES_TO_RESTART=(
    pvestatd.service
    pve-firewall.service
    pve-ha-lrm.service
    pve-ha-crm.service
    pvescheduler.service
    pve-guests.service
    ceph-mgr@pve.service
)

for service in "${SERVICES_TO_RESTART[@]}"; do
    echo "--> Restarting ${service}"
    systemctl restart "${service}" || echo "WARNING: Failed to restart ${service}. It may not be installed or enabled."
done

# --- 4. VERIFICATION CHECKS ---
echo
echo "--- Running Post-Checks ---"
echo

# Check 1: Failed services
echo "INFO: Checking for any remaining failed services..."
if systemctl --failed --no-pager | grep -q -v '0 loaded units'; then
    echo "ERROR: Some services are still in a failed state!"
    systemctl --failed --no-pager
else
    echo "SUCCESS: No failed systemd services found."
fi
echo

# Check 2: Cluster quorum status
echo "INFO: Checking cluster status with 'pvecm status'..."
pvecm status
echo

# Check 3: Proxmox API responsiveness
echo "INFO: Checking Proxmox API with 'pvesh get /nodes'..."
pvesh get /nodes
echo

# Check 4: Recent error logs
echo "INFO: Checking for new critical errors in the journal (last 2 minutes)..."
if journalctl --since "2 minutes ago" -p 0..3 --no-pager; then
    echo "SUCCESS: No critical errors found in recent logs."
fi

echo
echo "--- Recovery Attempt Finished ---"
echo "Please review the post-check output above. If all checks are successful, your node should be back online."

```