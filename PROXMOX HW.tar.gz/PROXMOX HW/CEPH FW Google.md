
# Guide to nftables on Proxmox VE

Proxmox VE, being based on Debian 12, uses `nftables` as the modern framework for packet filtering and firewall management, replacing the legacy `iptables`. This guide provides a comprehensive overview, a robust starting configuration, and numerous examples to secure your Proxmox host.

## **Part 1: Understanding nftables**

### **What is nftables?**

`nftables` is a netfilter project that provides a more efficient, scalable, and user-friendly way to manage firewall rules compared to `iptables`. Key advantages include:

- **Simplified Syntax:** The rules are more intuitive and easier to read.
    
- **Atomic Operations:** Entire rulesets can be updated in a single, atomic transaction, preventing partial rule application and firewall inconsistencies.
    
- **Better Performance:** It uses improved data structures (like sets and maps) for faster packet matching.
    
- **Unified Framework:** It manages IPv4, IPv6, ARP, and bridge filtering from a single utility.
    

### **Configuration File**

The primary configuration file for `nftables` is located at `/etc/nftables.conf`. This file is read by the `nftables` service on boot to load the firewall rules.

## **Part 2: Base Configuration for a Proxmox Host**

This configuration provides a secure starting point. It establishes a "default deny" policy for incoming traffic while allowing essential services for Proxmox to function correctly.

**To configure:**

1. Open the configuration file: `sudo nano /etc/nftables.conf`
    
2. Delete any existing content and paste the following:
    

```
#!/usr/sbin/nft -f

# Flush the existing ruleset completely
flush ruleset

# ==========================================================================
# Table: inet filter
# Handles both IPv4 and IPv6 traffic for filtering.
# ==========================================================================
table inet filter {
    # ----------------------------------------------------------------------
    # Sets for efficient IP matching
    # ----------------------------------------------------------------------
    set admin_ips {
        type ipv4_addr
        elements = { 192.168.1.100, 192.168.1.105 } # Add your admin workstation IPs here
    }

    # ----------------------------------------------------------------------
 **Ceph performance tuning checklist**     # Chain: input (for traffic destined for the Proxmox host itself)
    # ----------------------------------------------------------------------
    chain input {
        type filter hook input priority 0;
        policy drop; # Default policy: drop all incoming traffic

        # Allow traffic from established and related connections
        ct state {established, related} accept

        # Allow traffic from the loopback interface (localhost)
        iifname "lo" accept

        # Drop invalid packets
        ct state invalid drop

        # Allow ICMP (ping) for diagnostics
        ip protocol icmp accept
        ip6 nexthdr icmpv6 accept

        # Allow SSH access
        tcp dport 22 accept

        # Allow Proxmox Web UI access
        tcp dport 8006 accept

        # Allow Spice console access
        tcp dport 3128 accept

        # Allow migration traffic from other Proxmox nodes
        # tcp dport { 60000-60050 } accept # Uncomment if you have a cluster
    }

    # ----------------------------------------------------------------------
    # Chain: forward (for traffic passing through the Proxmox host, e.g., for VMs)
    # ----------------------------------------------------------------------
    chain forward {
        type filter hook forward priority 0;
        policy accept; # Default policy: allow traffic to/from VMs
                       # Proxmox manages VM firewalls separately.
    }

    # ----------------------------------------------------------------------
    # Chain: output (for traffic originating from the Proxmox host)
    # ----------------------------------------------------------------------
    chain output {
        type filter hook output priority 0;
        policy accept; # Default policy: allow all outgoing traffic
    }
}
```

### **Applying and Enabling the Ruleset**

1. **Test the configuration file for syntax errors:**
    
    ```
    sudo nft -c -f /etc/nftables.conf
    ```
    
    If no output is shown, the syntax is correct.
    
2. **Enable and start the `nftables` service:**
    
    ```
    sudo systemctl enable nftables
    sudo systemctl start nftables
    ```
    
    Your firewall is now active and will load automatically on boot.
    

## **Part 3: 20 `nftables` Examples**

These examples demonstrate how to add various rules. You can add them to the appropriate chain in your `/etc/nftables.conf` file or apply them directly from the command line.

Command Line Syntax: sudo nft add rule <family> <table> <chain> <rule>

Example: sudo nft add rule inet filter input tcp dport 443 accept

### **Constraining Access**

1. **Allow SSH only from specific admin IPs (using a set):**
    
    ```
    # Add this to the 'input' chain, replacing the general SSH rule
    tcp dport 22 ip saddr @admin_ips accept
    ```
    
2. **Block a specific malicious IP address from accessing anything:**
    
    ```
    # Add this at the top of the 'input' chain
    ip saddr 203.0.113.50 drop
    ```
    
3. **Allow Proxmox Web UI access only from your local network:**
    
    ```
    # Replace the general port 8006 rule
    tcp dport 8006 ip saddr 192.168.1.0/24 accept
    ```
    
4. Allow a specific VM to be accessed from the internet on port 80 (DNAT):
    
    Requires a nat table.
    
    ```
    # In a new table: table ip nat { chain prerouting { type nat hook prerouting priority -100; } }
    # Rule:
    iifname "enp1s0" tcp dport 80 dnat to 192.168.1.150:80
    ```
    
5. **Prevent a specific VM from accessing the internet:**
    
    ```
    # In the 'forward' chain
    ip saddr 192.168.1.150 oifname "enp1s0" drop
    ```
    
6. **Allow ICMP (ping) but rate-limit it to prevent floods:**
    
    ```
    # Replace the general ICMP rule
    ip protocol icmp limit rate 5/second accept
    ```
    
7. **Log and drop packets from a "noisy" IP before dropping them:**
    
    ```
    ip saddr 203.0.113.51 log prefix "Noisy IP Drop: " drop
    ```
    
8. Create a rule to explicitly drop all traffic from a specific country (requires a geoip set):
    
    This is an advanced use case requiring external tools to build the set.
    
    ```
    # Conceptual example
    ip saddr @blocked_countries drop
    ```
    

### **Traffic Shaping (TS) and Quality of Service (QoS)**

`nftables` is primarily used for _classifying_ and _marking_ packets. The actual shaping (throttling, prioritizing) is handled by other tools like `tc` (Traffic Control).

9. **Mark SSH traffic for high priority:**
    
    ```
    # In the 'output' chain
    tcp sport 22 meta mark set 0x1
    ```
    
10. **Mark web traffic from a specific VM for low priority:**
    
    ```
    # In the 'forward' chain
    ip saddr 192.168.1.200 tcp dport { 80, 443 } meta mark set 0x2
    ```
    
11. **Mark all traffic for a specific VM for accounting purposes:**
    
    ```
    # In the 'forward' chain
    ip saddr 192.168.1.210 meta mark set 0x10
    ```
    

### **General Configuration Examples**

12. **Allow inbound `traceroute` requests (UDP ports):**
    
    ```
    # In the 'input' chain
    udp dport 33434-33534 accept
    ```
    
13. **Allow NTP (Network Time Protocol) traffic for time synchronization:**
    
    ```
    # In the 'output' chain (for the host to get time)
    udp dport 123 accept
    ```
    
14. **Drop all `ident` (auth) requests immediately instead of waiting for a timeout:**
    
    ```
    # In the 'input' chain
    tcp dport 113 reject
    ```
    
15. **Allow DNS queries from the host:**
    
    ```
    # In the 'output' chain
    udp dport 53 accept
    tcp dport 53 accept
    ```
    
16. **Create a dedicated chain for logging dropped packets:**
    
    ```
    # At the end of the 'input' chain, jump to a logging chain
    chain log_and_drop {
        log prefix "Final Drop: "
        drop
    }
    # In 'input' chain, last rule:
    jump log_and_drop
    ```
    
17. **Implement brute-force protection for SSH:**
    
    ```
    # At the top of the 'input' chain
    set ssh_bruteforce {
        type ipv4_addr
        flags dynamic
        timeout 5m
    }
    tcp dport 22 ct state new add @ssh_bruteforce { ip saddr limit rate 4/minute }
    ```
    
18. **Allow traffic for a WireGuard VPN (port 51820/UDP):**
    
    ```
    # In the 'input' chain
    udp dport 51820 accept
    ```
    
19. **Allow iSCSI traffic from a specific storage network:**
    
    ```
    # In the 'input' chain
    ip saddr 10.10.20.0/24 tcp dport 3260 accept
    ```
    
20. Masquerade outbound traffic for VMs (SNAT):
    
    Requires a nat table.
    
    ```
    # In a new table: table ip nat { chain postrouting { type nat hook postrouting priority 100; } }
    # Rule:
    oifname "enp1s0" masquerade
    ```
21. 