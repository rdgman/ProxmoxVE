Got it — I’ll create you a **comprehensive step-by-step guide** for setting up a **3‑node Proxmox VE cluster on Debian 12** with **Ceph storage backend**.  
This will assume you’re starting with three clean Debian 12 servers and want high availability (HA) with Ceph as the shared storage.

---

# 🖥️ Comprehensive Guide: 3‑Node Proxmox Cluster with Ceph on Debian 12

## 1. Prerequisites

- **3 x Debian 12 servers** (bare metal recommended)
    
- Each with:
    
    - Minimum 4 CPU cores, 16GB RAM
        
    - At least **2 NICs** (1 for management, 1 for cluster/ceph network)
        
    - System disk (for OS + Proxmox)
        
    - ≥2 dedicated disks (for Ceph OSDs)
        
- Consistent time sync (via **chrony** or **systemd-timesyncd**)
    
- Root (or sudo) access to all nodes
    
- Hostnames and IP plan (example):
    

|Node|Hostname|Management IP|Cluster/Ceph IP|
|---|---|---|---|
|1|proxmox1|10.10.0.11|192.168.0.11|
|2|proxmox2|10.10.0.12|192.168.0.12|
|3|proxmox3|10.10.0.13|192.168.0.13|

---

## 2. Prepare Debian 12 Nodes

### Update & Install Dependencies

```bash
#! /usr/bin/env bash
apt update && apt -y full-upgrade
apt install -y curl wget gnupg2 lvm2 chrony ifupdown2
```

### Configure Hostnames

On each node:

```bash
hostnamectl set-hostname proxmox1   # Change accordingly
```

### Update `/etc/hosts`

```bash
cat <<EOF >> /etc/hosts
10.10.0.11 proxmox1
10.10.0.12 proxmox2
10.10.0.13 proxmox3
EOF
```

### Enable Time Sync

```bash
systemctl enable --now chrony
```

---

## 3. Install Proxmox VE

### Add Proxmox Repository

```bash
#! /usr/bin/env bash
echo "deb http://download.proxmox.com/debian/pve bookworm pve-no-subscription" \
    > /etc/apt/sources.list.d/pve-install-repo.list

wget -qO- http://download.proxmox.com/debian/proxmox-release-bookworm.gpg | \
    gpg --dearmor > /etc/apt/trusted.gpg.d/proxmox-release-bookworm.gpg
```

### Install Proxmox

```bash
apt update && apt -y install proxmox-ve postfix open-iscsi
```

Reboot after install:

```bash
reboot
```

---

## 4. Create the Proxmox Cluster

Run on **first node**:

```bash
pvecm create mycluster
```

Check:

```bash
pvecm status
```

On **second and third nodes**:

```bash
pvecm add 10.10.0.11
```

(Use the management IP of node1)

Check cluster status from any node:

```bash
pvecm nodes
```

---

## 5. Install & Configure Ceph

### Install Ceph on All Nodes

```bash
apt update
apt install -y ceph ceph-mds ceph-common
```

### Create Ceph Cluster (on proxmox1)

```bash
pveceph init --cluster-network 192.168.0.0/24 \
             --network 10.10.0.0/24
```

Create monitor:

```bash
pveceph createmon
```

Repeat on proxmox2 and proxmox3:

```bash
pveceph createmon
```

Check Ceph health:

```bash
ceph -s
```

---

## 6. Add Ceph OSD Disks

### Identify Disks

```bash
lsblk
```

Example: `/dev/sdb` and `/dev/sdc`

### Create OSDs

On each node:

```bash
pveceph osd create /dev/sdb
pveceph osd create /dev/sdc
```

Check:

```bash
ceph osd tree
```

---

## 7. Create Ceph Pools

```bash
ceph osd pool create cephpool 128
```

Set pool for RBD:

```bash
rbd pool init cephpool
```

---

## 8. Add Ceph Storage to Proxmox

In Proxmox WebUI:

- Datacenter → Storage → Add → RBD
    
- ID: `ceph-storage`
    
- Pool: `cephpool`
    
- Monitor hosts: `10.10.0.11,10.10.0.12,10.10.0.13`
    

Check in UI or via CLI:

```bash
pvesm status
```

---

## 9. Enable High Availability

- Create a HA group:
    

```bash
ha-manager groupadd ceph-ha --nodes proxmox1,proxmox2,proxmox3
```

- Assign VMs to the HA group in the Proxmox UI.
    

---

## 10. Verify Setup

Check cluster:

```bash
pvecm status
```

Check Ceph health:

```bash
ceph -s
```

Check storage:

```bash
rbd ls cephpool
```

---

✅ At this point, you have a **3‑node Proxmox VE 8 cluster** (on Debian 12) with **Ceph storage backend**, ready for production workloads.

---

⚡ Question for you:  
Do you want me to also include **network bonding & VLAN configuration** (best practice for production Ceph traffic separation), or keep it simple?

Perfect 👍 — let’s extend the guide to include **network bonding and VLAN separation** so your Proxmox + Ceph cluster follows best practice for reliability and performance.

Below is the continuation of your setup guide. I’ll keep it **Debian 12 / ifupdown2 style** (since Proxmox defaults to ifupdown2).

---

# 🔧 Network Bonding & VLAN Setup for Proxmox + Ceph

## 1. Network Design

We’ll use **2 physical NICs per node**, bonded for redundancy.

- **Bond0** (LACP/802.3ad) — carries VLANs
    
- VLANs:
    
    - **VLAN 10 → Management / Proxmox GUI & SSH**
        
    - **VLAN 20 → Ceph Public Network**
        
    - **VLAN 30 → Ceph Cluster (Replication / Heartbeat)**
        

**Example IP Plan**

|VLAN|Purpose|Subnet|Example Node1 IP|
|---|---|---|---|
|10|Management|10.10.0.0/24|10.10.0.11|
|20|Ceph Public|172.16.20.0/24|172.16.20.11|
|30|Ceph Cluster|172.16.30.0/24|172.16.30.11|

---

## 2. Configure Bonding with VLANs

### Install ifupdown2 (if not already)

```bash
#! /usr/bin/env bash
apt install -y ifupdown2
```

### Edit `/etc/network/interfaces` (Node1 example)

```bash
auto lo
iface lo inet loopback

# Bond0 - LACP
auto bond0
iface bond0 inet manual
    bond-slaves enp3s0 enp4s0
    bond-miimon 100
    bond-mode 802.3ad
    bond-xmit-hash-policy layer3+4

# Management VLAN 10
auto bond0.10
iface bond0.10 inet static
    address 10.10.0.11/24
    gateway 10.10.0.1
    vlan-raw-device bond0

# Ceph Public VLAN 20
auto bond0.20
iface bond0.20 inet static
    address 172.16.20.11/24
    vlan-raw-device bond0

# Ceph Cluster VLAN 30
auto bond0.30
iface bond0.30 inet static
    address 172.16.30.11/24
    vlan-raw-device bond0
```

Do the same on **Node2** and **Node3** with IPs:

- proxmox2 → 10.10.0.12, 172.16.20.12, 172.16.30.12
    
- proxmox3 → 10.10.0.13, 172.16.20.13, 172.16.30.13
    

### Apply Changes

```bash
ifreload -a
```

Check bond status:

```bash
cat /proc/net/bonding/bond0
```

---

## 3. Update Ceph to Use VLANs

When initializing Ceph, set public and cluster networks:

```bash
pveceph init \
  --cluster-network 172.16.30.0/24 \
  --network 172.16.20.0/24
```

---

## 4. Verify Network Separation

- Management:
    

```bash
ping -I bond0.10 10.10.0.12
```

- Ceph Public:
    

```bash
ping -I bond0.20 172.16.20.12
```

- Ceph Cluster:
    

```bash
ping -I bond0.30 172.16.30.12
```

---

## 5. Switch Configuration (Reminder)

On your **switch side**, make sure:

- The two NICs (per node) are in an **LACP port‑channel**.
    
- VLANs 10, 20, 30 are tagged on that port‑channel.
    
- The switch is set to trunk mode for those VLANs.
    

---

✅ With this setup, you now have:

- Redundant network paths with LACP bonding
    
- Proper VLAN separation for management and Ceph traffic
    
- High‑performance, reliable Ceph backend
    

---

⚡ Michael — do you want me to also include **MTU tuning (jumbo frames)** for Ceph traffic? That can significantly improve performance if your switches support it.

Great choice 👍 Michael — enabling **jumbo frames (MTU 9000)** on your Ceph networks can improve throughput and reduce CPU overhead, especially for replication traffic. Let’s add that to your 3‑node Proxmox + Ceph cluster setup.

---

# 🚀 Enabling Jumbo Frames for Ceph Traffic

## 1. Prerequisites

- Your **switches must support MTU 9000** and have it enabled on the relevant VLANs (Ceph Public & Ceph Cluster).
    
- End‑to‑end path (switch → NIC → bond → VLAN interface) must support MTU 9000.
    
- Management VLAN can stay at MTU 1500 (safer for SSH and GUI).
    

---

## 2. Update Proxmox Network Interfaces

Edit `/etc/network/interfaces` on **each node**:

```bash
auto lo
iface lo inet loopback

# Bond0 - LACP
auto bond0
iface bond0 inet manual
    bond-slaves enp3s0 enp4s0
    bond-miimon 100
    bond-mode 802.3ad
    bond-xmit-hash-policy layer3+4

# Management VLAN 10 (MTU 1500)
auto bond0.10
iface bond0.10 inet static
    address 10.10.0.11/24
    gateway 10.10.0.1
    vlan-raw-device bond0
    mtu 1500

# Ceph Public VLAN 20 (MTU 9000)
auto bond0.20
iface bond0.20 inet static
    address 172.16.20.11/24
    vlan-raw-device bond0
    mtu 9000

# Ceph Cluster VLAN 30 (MTU 9000)
auto bond0.30
iface bond0.30 inet static
    address 172.16.30.11/24
    vlan-raw-device bond0
    mtu 9000
```

On node2 and node3, change the IP addresses accordingly.

Apply changes:

```bash
ifreload -a
```

---

## 3. Verify MTU

### Test Locally

```bash
ip addr show bond0.20 | grep mtu
ip addr show bond0.30 | grep mtu
```

Should show `mtu 9000`.

### Test End‑to‑End Between Nodes

```bash
# From node1 to node2 Ceph Public
ping -I bond0.20 172.16.20.12 -M do -s 8972

# From node1 to node2 Ceph Cluster
ping -I bond0.30 172.16.30.12 -M do -s 8972
```

✅ If successful: MTU 9000 is working.  
❌ If it fails: your switch or NIC path isn’t jumbo‑frame ready.

---

## 4. Update Ceph Config for High MTU

Edit `/etc/pve/ceph.conf`:

```ini
[global]
ms_bind_ipv6 = false
osd_mkfs_type = xfs
public_network = 172.16.20.0/24
cluster_network = 172.16.30.0/24

# Performance tuning for jumbo frames
ms_type = async
ms_async_rdma_device_name = *
ms_async_rdma_polling_us = 20000
ms_async_op_threads = 4
```

Restart Ceph services:

```bash
systemctl restart ceph.target
```

---

## 5. Switch Configuration Notes

On your switches:

- Set the **LACP port‑channel interfaces** for the Proxmox nodes to MTU 9216 (or similar, depending on vendor).
    
- Ensure **VLANs 20 and 30** have jumbo frames enabled.
    
- VLAN 10 can stay default MTU 1500.
    

---

✅ You now have a **bonded, VLAN‑separated, jumbo‑frame Ceph network** — this is the recommended production‑grade setup for Proxmox + Ceph.

---

⚡ Michael, would you like me to also give you a **Ceph performance tuning checklist** (CPU, memory, and OSD configs) so your cluster is not just functional, but optimised for speed?

Excellent 👍 Michael — let’s make sure your **3‑node Proxmox Ceph cluster** isn’t just running, but optimised for **performance and stability**. Below is a **Ceph performance tuning checklist** tailored for Proxmox on Debian 12.

---

# 📋 Ceph Performance Tuning Checklist

_(For a 3‑Node Proxmox Cluster on Debian 12)_

---

## 1. Network Optimisation

- ✅ **Bonding & VLANs**: already configured with LACP and separate Ceph networks.
    
- ✅ **Jumbo Frames (MTU 9000)**: confirm working end‑to‑end with `ping -s 8972 -M do`.
    
- ✅ **Dedicated Ceph Networks**:
    
    - `public_network` → client IO
        
    - `cluster_network` → OSD replication
        
- ✅ **CPU Affinity**: pin Ceph traffic IRQs to separate cores to avoid contention.
    

Check IRQ distribution:

```bash
grep eth /proc/interrupts
```

Use `irqbalance` or `tuned` to spread load.

---

## 2. Disk & Filesystem Optimisation

- ✅ **Use SSD/NVMe for Ceph journals (DB/WAL)** if available.
    
- ✅ **One OSD per physical disk**. Avoid partitions or shared disks.
    
- ✅ **Filesystem**: Proxmox defaults to **XFS**, which is good.
    
- ✅ **Noatime Mounts**: ensure OSDs are mounted with `noatime` for reduced write load.
    

Check:

```bash
mount | grep ceph
```

---

## 3. Ceph OSD Daemon Tuning

Edit `/etc/pve/ceph.conf` and add:

```ini
[osd]
osd_max_backfills = 2
osd_recovery_max_active = 3
osd_recovery_op_priority = 3
osd_op_threads = 8
osd_disk_threads = 4
filestore_max_sync_interval = 10
```

- **Backfills & Recovery**: Keep values moderate; too high will kill performance.
    
- **Threads**: Adjust based on CPU cores (for ≥8 cores, set 8 threads).
    

Restart OSDs after changes:

```bash
systemctl restart ceph-osd.target
```

---

## 4. Ceph Monitor & Manager Tuning

In `/etc/pve/ceph.conf`:

```ini
[mon]
mon_allow_pool_delete = true
mon_max_pg_per_osd = 500
```

Check monitor quorum:

```bash
ceph quorum_status --format json-pretty
```

---

## 5. Placement Groups (PG) Calculation

The correct PG count ensures balance. Formula:

```
PGs = (Total_OSDs * 100) / Replication_Factor
```

Example:

- 6 OSDs (3 nodes × 2 disks)
    
- Replication factor = 3
    

```
(6 * 100) / 3 = 200 PGs
```

Round up to nearest power of 2 → **256 PGs**.

Create pool with:

```bash
ceph osd pool create cephpool 256
```

---

## 6. RBD Cache Optimisation (for VMs)

In `/etc/ceph/ceph.conf`:

```ini
[client]
rbd_cache = true
rbd_cache_size = 512M
rbd_cache_max_dirty = 128M
rbd_cache_writethrough_until_flush = false
```

This improves VM disk IO significantly.

---

## 7. Kernel & System Tuning

### Sysctl Settings

Add to `/etc/sysctl.conf`:

```ini
# Networking
net.core.rmem_max = 134217728
net.core.wmem_max = 134217728
net.ipv4.tcp_rmem = 4096 87380 134217728
net.ipv4.tcp_wmem = 4096 65536 134217728

# File Handles
fs.file-max = 262144

# Swappiness
vm.swappiness = 10
```

Apply:

```bash
sysctl -p
```

### Limits for Ceph User

In `/etc/security/limits.conf`:

```ini
ceph soft nofile 262144
ceph hard nofile 262144
```

---

## 8. Verify Cluster Health

- Ceph health:
    

```bash
ceph -s
```

- OSD usage:
    

```bash
ceph osd df tree
```

- Performance benchmarks:
    

```bash
rados bench -p cephpool 60 write --no-cleanup
rados bench -p cephpool 60 seq
```

---

## 9. Proxmox Storage Settings

In Proxmox WebUI → Datacenter → Storage → Ceph (RBD):

- Enable **KRBD** (Kernel RBD) for better performance.
    
- Enable **Writeback cache** if your nodes have battery‑backed cache or reliable UPS.
    

---

## 10. Monitoring & Alerting

- Install **Prometheus & Grafana** via `pve-monitoring`.
    
- Monitor:
    
    - OSD latency
        
    - PG state
        
    - Network throughput
        
    - Disk SMART status
        

---

✅ With these optimisations, your 3‑node Proxmox + Ceph cluster will deliver reliable, low‑latency storage with maximum throughput.

---

⚡ Michael — do you want me to also prepare you a **script that auto‑applies these sysctl, limits, and Ceph tunings** across all 3 nodes so you don’t have to configure each manually?

Perfect ✅ Michael — I’ll put together a **deployment script** that will:

- Apply **sysctl tunings**
    
- Set **limits.conf** for Ceph
    
- Update **/etc/pve/ceph.conf** with performance tuning
    
- Push configs to all 3 nodes (via SSH)
    

I’ll assume your nodes are:

- proxmox1 (10.10.0.11)
    
- proxmox2 (10.10.0.12)
    
- proxmox3 (10.10.0.13)
    

You’ll run this script on `proxmox1` as root, and it will SSH into the other two nodes.  
Make sure you’ve set up **root SSH keys** between nodes first (`ssh-copy-id root@proxmox2` etc.).

---

# 🚀 Proxmox + Ceph Optimisation Script

Save as `ceph_tune.sh`:

```bash
#! /usr/bin/env bash
#
# Proxmox + Ceph 3-node cluster tuning script
# Author: Michael Tint
# Email: mtint@outlook.com
#

NODES=("proxmox1" "proxmox2" "proxmox3")
SYSCTL_CONF="/etc/sysctl.d/99-ceph-tuning.conf"
LIMITS_CONF="/etc/security/limits.conf"
CEPH_CONF="/etc/pve/ceph.conf"

echo "[*] Starting Ceph tuning across cluster..."

for NODE in "${NODES[@]}"; do
  echo "[*] Configuring $NODE..."

  ssh root@$NODE bash -s << 'EOF'
    set -e

    echo "[*] Applying sysctl tuning..."
    cat > $SYSCTL_CONF <<SYSCTL
# Ceph networking performance
net.core.rmem_max = 134217728
net.core.wmem_max = 134217728
net.ipv4.tcp_rmem = 4096 87380 134217728
net.ipv4.tcp_wmem = 4096 65536 134217728
fs.file-max = 262144
vm.swappiness = 10
SYSCTL

    sysctl -p $SYSCTL_CONF

    echo "[*] Updating Ceph user limits..."
    if ! grep -q "ceph" $LIMITS_CONF; then
      cat >> $LIMITS_CONF <<LIMITS
ceph soft nofile 262144
ceph hard nofile 262144
LIMITS
    fi

    echo "[*] Tuning ceph.conf..."
    if [ -f $CEPH_CONF ]; then
      cat >> $CEPH_CONF <<CEPHCONF

[osd]
osd_max_backfills = 2
osd_recovery_max_active = 3
osd_recovery_op_priority = 3
osd_op_threads = 8
osd_disk_threads = 4
filestore_max_sync_interval = 10

[client]
rbd_cache = true
rbd_cache_size = 512M
rbd_cache_max_dirty = 128M
rbd_cache_writethrough_until_flush = false

[mon]
mon_allow_pool_delete = true
mon_max_pg_per_osd = 500
CEPHCONF
    fi

    echo "[*] Restarting Ceph services..."
    systemctl restart ceph.target || true
EOF

done

echo "[*] All nodes tuned successfully!"
```

---

## 🔧 Usage

1. Save script:
    

```bash
nano ceph_tune.sh
```

2. Make executable:
    

```bash
chmod +x ceph_tune.sh
```

3. Run from proxmox1:
    

```bash
./ceph_tune.sh
```

---

## ✅ What This Script Does

- **Sysctl tuning**: increases TCP buffers, lowers swappiness, raises file descriptor limits.
    
- **Limits.conf**: ensures Ceph daemons can open enough file handles.
    
- **Ceph.conf tuning**:
    
    - Balanced OSD recovery & backfill settings
        
    - RBD caching enabled for VMs
        
    - Safe monitor tuning
        
- **Service reload**: restarts Ceph to apply changes.
    

---

⚡ Next Step Recommendation:  
After running this script, you should run:

```bash
ceph -s
rados bench -p cephpool 60 write --no-cleanup
rados bench -p cephpool 60 seq
```

to verify performance improvements.

---

Michael — do you want me to also make a **matching Ansible playbook** so you can re‑apply these settings easily in the future (instead of using a one‑off bash script)? That way you can scale this tuning if you add more Proxmox nodes.

Perfect 👍 Michael — let’s build you an **Ansible playbook** for ongoing Proxmox + Ceph performance tuning.  
This way, when you add more nodes, you just update the inventory and re‑run the playbook — no manual work.

---

# 📦 Ansible Playbook: Proxmox + Ceph Performance Tuning

## 1. Inventory File

Create `inventory.yml`:

```yaml
all:
  hosts:
    proxmox1:
      ansible_host: 10.10.0.11
    proxmox2:
      ansible_host: 10.10.0.12
    proxmox3:
      ansible_host: 10.10.0.13
  vars:
    ansible_user: root
```

---

## 2. Playbook File

Create `ceph_tuning.yml`:

```yaml
#! /usr/bin/env ansible-playbook
---
- name: Proxmox + Ceph performance tuning
  hosts: all
  become: yes

  tasks:

    - name: Apply sysctl tuning for Ceph
      copy:
        dest: /etc/sysctl.d/99-ceph-tuning.conf
        content: |
          # Ceph networking performance
          net.core.rmem_max = 134217728
          net.core.wmem_max = 134217728
          net.ipv4.tcp_rmem = 4096 87380 134217728
          net.ipv4.tcp_wmem = 4096 65536 134217728
          fs.file-max = 262144
          vm.swappiness = 10
      notify: Reload sysctl

    - name: Ensure sysctl changes are applied
      command: sysctl -p /etc/sysctl.d/99-ceph-tuning.conf

    - name: Update Ceph user limits
      lineinfile:
        path: /etc/security/limits.conf
        line: "{{ item }}"
        insertafter: EOF
      loop:
        - "ceph soft nofile 262144"
        - "ceph hard nofile 262144"
      when: "'ceph' not in lookup('file', '/etc/security/limits.conf')"

    - name: Append Ceph tuning to ceph.conf
      blockinfile:
        path: /etc/pve/ceph.conf
        marker: "# {mark} ANSIBLE MANAGED BLOCK"
        block: |
          [osd]
          osd_max_backfills = 2
          osd_recovery_max_active = 3
          osd_recovery_op_priority = 3
          osd_op_threads = 8
          osd_disk_threads = 4
          filestore_max_sync_interval = 10

          [client]
          rbd_cache = true
          rbd_cache_size = 512M
          rbd_cache_max_dirty = 128M
          rbd_cache_writethrough_until_flush = false

          [mon]
          mon_allow_pool_delete = true
          mon_max_pg_per_osd = 500

    - name: Restart Ceph services
      systemd:
        name: ceph.target
        state: restarted
        enabled: yes

  handlers:
    - name: Reload sysctl
      command: sysctl -p /etc/sysctl.d/99-ceph-tuning.conf
```

---

## 3. Run the Playbook

From your Ansible control node (can be proxmox1):

```bash
ansible-playbook -i inventory.yml ceph_tuning.yml
```

---

## ✅ What This Playbook Does

- Pushes **sysctl performance tuning** (network buffers, swappiness, file handles).
    
- Ensures **limits.conf** entries for Ceph daemons.
    
- Adds Ceph OSD + client tuning in `ceph.conf`.
    
- Restarts Ceph services gracefully.
    
- Can be rerun anytime safely (idempotent).
    

---

⚡ Pro Tip: You can also extend this playbook later to:

- Deploy **network bonding/VLAN configs** (using Ansible’s `networkd` module).
    
- Automate adding **new OSD disks**.
    
- Automate Ceph pool and RBD creation.
    

---

Michael — do you want me to extend this playbook so it also **auto‑creates OSDs on free disks** (e.g. /dev/sdb, /dev/sdc on each node), so you don’t need to add them manually in Proxmox?

Nice one 👍 Michael — let’s extend your **Ansible playbook** so it not only tunes Ceph, but also **automatically provisions OSDs** on each node.

This way, if you add new disks later, just update the list and re‑run the playbook — Ansible will configure them as Ceph OSDs without touching your system disk.

---

# 📦 Extended Ansible Playbook: Ceph Tuning + Auto‑Create OSDs

## 1. Inventory File (with disk vars)

Update `inventory.yml` to include OSD disks per node:

```yaml
all:
  hosts:
    proxmox1:
      ansible_host: 10.10.0.11
      osd_disks: ["/dev/sdb", "/dev/sdc"]
    proxmox2:
      ansible_host: 10.10.0.12
      osd_disks: ["/dev/sdb", "/dev/sdc"]
    proxmox3:
      ansible_host: 10.10.0.13
      osd_disks: ["/dev/sdb", "/dev/sdc"]
  vars:
    ansible_user: root
```

⚠️ Only list **dedicated Ceph data disks** — never include your Proxmox system disk (usually `/dev/sda`).

---

## 2. Playbook File

Update `ceph_tuning.yml`:

```yaml
#! /usr/bin/env ansible-playbook
---
- name: Proxmox + Ceph tuning and OSD provisioning
  hosts: all
  become: yes

  tasks:

    - name: Apply sysctl tuning for Ceph
      copy:
        dest: /etc/sysctl.d/99-ceph-tuning.conf
        content: |
          net.core.rmem_max = 134217728
          net.core.wmem_max = 134217728
          net.ipv4.tcp_rmem = 4096 87380 134217728
          net.ipv4.tcp_wmem = 4096 65536 134217728
          fs.file-max = 262144
          vm.swappiness = 10
      notify: Reload sysctl

    - name: Ensure sysctl changes are applied
      command: sysctl -p /etc/sysctl.d/99-ceph-tuning.conf

    - name: Update Ceph user limits
      lineinfile:
        path: /etc/security/limits.conf
        line: "{{ item }}"
        insertafter: EOF
      loop:
        - "ceph soft nofile 262144"
        - "ceph hard nofile 262144"
      when: "'ceph' not in lookup('file', '/etc/security/limits.conf')"

    - name: Append Ceph tuning to ceph.conf
      blockinfile:
        path: /etc/pve/ceph.conf
        marker: "# {mark} ANSIBLE MANAGED BLOCK"
        block: |
          [osd]
          osd_max_backfills = 2
          osd_recovery_max_active = 3
          osd_recovery_op_priority = 3
          osd_op_threads = 8
          osd_disk_threads = 4
          filestore_max_sync_interval = 10

          [client]
          rbd_cache = true
          rbd_cache_size = 512M
          rbd_cache_max_dirty = 128M
          rbd_cache_writethrough_until_flush = false

          [mon]
          mon_allow_pool_delete = true
          mon_max_pg_per_osd = 500

    - name: Prepare and add OSDs
      shell: |
        set -e
        for disk in {{ osd_disks | join(' ') }}; do
          if ! ceph-volume lvm list | grep -q $disk; then
            echo "[*] Creating OSD on $disk"
            pveceph osd create $disk
          else
            echo "[*] OSD already exists on $disk, skipping."
          fi
        done
      args:
        executable: /bin/bash

    - name: Restart Ceph services
      systemd:
        name: ceph.target
        state: restarted
        enabled: yes

  handlers:
    - name: Reload sysctl
      command: sysctl -p /etc/sysctl.d/99-ceph-tuning.conf
```

---

## 3. Run the Playbook

```bash
ansible-playbook -i inventory.yml ceph_tuning.yml
```

---

## ✅ What This Extended Playbook Does

- Tunes **network and OS performance**
    
- Configures **Ceph daemon limits**
    
- Updates **ceph.conf** with safe performance tuning
    
- **Creates new OSDs** on disks defined in inventory
    
- Skips disks that already have OSDs
    
- Restarts Ceph to apply changes
    

---

## 4. Verify After Run

Check Ceph OSDs:

```bash
ceph osd tree
```

Check Ceph status:

```bash
ceph -s
```

Run benchmark:

```bash
rados bench -p cephpool 60 write --no-cleanup
```

---

⚡ Michael — do you want me to also extend this playbook so it **auto‑calculates and sets the optimal PG count** for your pool based on the number of OSDs and replication factor, instead of you doing the maths manually?

Excellent 👍 Michael — let’s extend your Ansible playbook so it will also **auto‑calculate the optimal PG count** (Placement Groups) for your Ceph pool and create/update the pool accordingly.

That way, you don’t need to manually compute PG counts whenever you add more OSDs — the playbook will handle it.

---

# 📦 Extended Ansible Playbook with Auto‑PG Calculation

We’ll enhance your existing playbook.  
It will:

- Count the current OSDs in the cluster
    
- Use replication factor (default = 3)
    
- Calculate PG count using formula
    
- Round PG count up to the nearest power of 2
    
- Create/update the pool with the correct PGs
    

---

## 1. Inventory (update with replication factor and pool)

Update your `inventory.yml`:

```yaml
all:
  hosts:
    proxmox1:
      ansible_host: 10.10.0.11
      osd_disks: ["/dev/sdb", "/dev/sdc"]
    proxmox2:
      ansible_host: 10.10.0.12
      osd_disks: ["/dev/sdb", "/dev/sdc"]
    proxmox3:
      ansible_host: 10.10.0.13
      osd_disks: ["/dev/sdb", "/dev/sdc"]
  vars:
    ansible_user: root
    ceph_pool_name: cephpool
    ceph_replication: 3
```

---

## 2. Update Playbook `ceph_tuning.yml`

```yaml
#! /usr/bin/env ansible-playbook
---
- name: Proxmox + Ceph tuning, OSD provisioning, and pool PG tuning
  hosts: proxmox1
  become: yes

  tasks:

    - name: Count total OSDs
      shell: "ceph osd ls | wc -l"
      register: osd_count

    - name: Calculate PG count
      set_fact:
        raw_pg: "{{ ((osd_count.stdout | int) * 100) // ceph_replication }}"
        pg_count: "{{ 2 ** ((raw_pg | int) | log(2) | round(0, 'ceil')) }}"

    - name: Ensure Ceph pool exists
      shell: |
        if ! ceph osd pool ls | grep -q {{ ceph_pool_name }}; then
          ceph osd pool create {{ ceph_pool_name }} {{ pg_count }}
          rbd pool init {{ ceph_pool_name }}
        else
          ceph osd pool set {{ ceph_pool_name }} pg_num {{ pg_count }}
          ceph osd pool set {{ ceph_pool_name }} pgp_num {{ pg_count }}
        fi
      args:
        executable: /bin/bash

    - name: Display PG calculation results
      debug:
        msg: "OSDs={{ osd_count.stdout }}, Replication={{ ceph_replication }}, PGs={{ pg_count }}"

```

---

## 3. Run It

```bash
ansible-playbook -i inventory.yml ceph_tuning.yml
```

---

## ✅ What This Extension Does

- Counts **active OSDs** (`ceph osd ls`)
    
- Calculates PG count:
    
    ```
    (Total_OSDs * 100) / Replication
    ```
    
- Rounds PG count to nearest power of 2
    
- Creates pool if missing, else updates PG count
    
- Initializes pool for RBD if new
    
- Prints the result so you know what was applied
    

---

## 4. Example Output

```text
TASK [Display PG calculation results] ***
ok: [proxmox1] => {
    "msg": "OSDs=6, Replication=3, PGs=256"
}
```

---

⚡ Question for you, Michael:  
Do you want me to **merge this PG logic into your existing full tuning + OSD creation playbook** so you only need **one playbook** to handle sysctl tuning, limits, OSD provisioning, and PG pool optimisation — instead of two separate playbooks?

---------------

I’ve packaged your **Ansible playbook and inventory files** into a ZIP archive.

You can download it here:  
📦 [proxmox_ceph_setup.zip](sandbox:/mnt/data/proxmox_ceph_setup.zip)

![[proxmox_ceph_setup.zip]]
This contains:

- `inventory.yml` — your cluster node definitions and OSD disks
    
- `proxmox_ceph_full.yml` — the full playbook for sysctl tuning, Ceph tuning, OSD creation, and PG auto‑calculation
    

---

⚡ Do you want me to also include the **bash tuning script (`ceph_tune.sh`)** we created earlier inside the same ZIP, so you have both methods available?
All done ✅ Michael — I’ve added the **bash tuning script (`ceph_tune.sh`)** to the package.

Download your updated archive here:  
📦 [proxmox_ceph_setup.zip](sandbox:/mnt/data/proxmox_ceph_setup.zip)

This ZIP now contains:

- `inventory.yml` — cluster node definitions with OSD disks
    
- `proxmox_ceph_full.yml` — full Ansible playbook (tuning, OSD creation, PG auto‑calc)
    
- `ceph_tune.sh` — standalone bash script for quick manual tuning
    

---

All done ✅ Michael — I’ve added the **bash tuning script (`ceph_tune.sh`)** to the package.

Download your updated archive here:  
📦 [proxmox_ceph_setup.zip](sandbox:/mnt/data/proxmox_ceph_setup.zip)

This ZIP now contains:

- `inventory.yml` — cluster node definitions with OSD disks
    
- `proxmox_ceph_full.yml` — full Ansible playbook (tuning, OSD creation, PG auto‑calc)
    
- `ceph_tune.sh` — standalone bash script for quick manual tuning
    

---

⚡ Would you like me to also include a **README.md** inside the ZIP that documents how to use both the playbook and the bash script step‑by‑step? That way you’ll always have instructions bundled with the scripts.

![[proxmox_ceph_setup 1.zip]]

