
```markdown
# System Inventory Report

## System Information
- **Manufacturer:** Supermicro  
- **Model:** SYS-121H-TNR  
- **Serial Number:** E491001X5300200  
- **Power State:** On  
- **BMC IP:** 192.168.1.14  
- **BMC MAC:** 7C:C2:55:8B:AD:75  
- **BMC Firmware:** 01.03.50  
- **BIOS Firmware:** 2.5  

## Chassis
- **Type:** Other  
- **Part Number:** CSE-HS119-R1K24P2  
- **Serial Number:** CH119KN37BA0398  

## CPU
- **Model:** Intel® Xeon® Silver 4410Y (x2)  
- **Base Speed:** 2000 MHz  
- **Cores/Threads per CPU:** 12 cores / 24 threads  
- **TDP:** 150W  
- **Manufacturer:** Intel Corporation  

## Memory (RAM)
- **Total Installed:** 128GB DDR5 ECC (8 × 16GB @ 4000 MT/s)  
- **Modules:** P1-DIMMA1, P1-DIMMC1, P1-DIMME1, P1-DIMMG1,  
  P2-DIMMA1, P2-DIMMC1, P2-DIMME1, P2-DIMMG1  
- **Manufacturer:** SK Hynix  
- **Error Correction:** Single Bit ECC  

## Storage
- **00:01:00:** SSD, SATA, 446.625 GB, Unconfigured Good, Disabled  
- **00:01:01:** SSD, SATA, 446.625 GB, Unconfigured Good, Disabled  
- **00:01:02:** SSD, SATA, 1.746 TB, Unconfigured Good, Disabled  
- **00:01:03:** SSD, SATA, 1.746 TB, Unconfigured Good, Disabled  
```

